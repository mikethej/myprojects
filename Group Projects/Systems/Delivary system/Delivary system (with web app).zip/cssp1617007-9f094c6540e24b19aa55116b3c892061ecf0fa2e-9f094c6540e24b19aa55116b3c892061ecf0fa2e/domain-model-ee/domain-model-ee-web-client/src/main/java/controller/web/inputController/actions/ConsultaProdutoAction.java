package controller.web.inputController.actions;

import java.io.IOException;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import presentation.web.model.ConsultaProdutoModel;
import facade.handlers.ProcessOrderHandlerRemote;

@Stateless
public class ConsultaProdutoAction extends Action{

	@EJB private ProcessOrderHandlerRemote processOrderHandler;

	@Override
	public void process(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		ConsultaProdutoModel model = new ConsultaProdutoModel();
		model.setProcessOrderHandler(processOrderHandler);
		request.setAttribute("model", model);
		request.getRequestDispatcher("/encomendas/consultaProduto.jsp").forward(request, response);
	}
}

