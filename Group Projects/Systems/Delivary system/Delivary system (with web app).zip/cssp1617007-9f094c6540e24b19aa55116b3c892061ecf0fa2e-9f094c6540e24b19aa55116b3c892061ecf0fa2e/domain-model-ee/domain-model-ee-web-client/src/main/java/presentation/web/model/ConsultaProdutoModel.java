package presentation.web.model;

import facade.handlers.ProcessOrderHandlerRemote;

public class ConsultaProdutoModel extends Model {

	private String id;
	private ProcessOrderHandlerRemote processOrderHandler;
	
	public void setProcessOrderHandler(ProcessOrderHandlerRemote processOrderHandler){
		this.processOrderHandler = processOrderHandler;
	}
	public ProcessOrderHandlerRemote getProcessOrderHandler(){
		return processOrderHandler;
	}
	
	public void setid(String id){
		this.id = id;
	}
	
	public String getid(){
		return id;
	}
	
	public void clearFields() {
		id = "";
	}
}