package presentation.web.model;


import facade.handlers.ProcessSaleHandlerRemote;

public class NewSaleModel extends Model {

	private String vatNumber;
	private String product_id;
	private String qty;
	private ProcessSaleHandlerRemote processSaleHandler;
	
	public void setProcessSaleHandler(ProcessSaleHandlerRemote processSaleHandler){
		this.processSaleHandler = processSaleHandler;
	}
	public ProcessSaleHandlerRemote getProcessSaleHandler() {
		return processSaleHandler;
	}
	
	public void setVatNumber(String vatNumber){
		this.vatNumber = vatNumber;
	}
	
	public void setProductId(String product_id){
		this.product_id = product_id;
	}
	
	public void setQty(String qty){
		this.qty = qty;
	}
	
	public String vatNumber(){
		return vatNumber;
	}
	
	public String getProductId(){
		return product_id;
	}
	public String getQty(){
		return qty;
	}
	
	public void clearFields() {
		vatNumber = "";
	}
}
