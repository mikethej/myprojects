package controller.web.inputController.actions;

import java.io.IOException;
import java.sql.SQLException;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import presentation.web.model.EncomendasModel;
import facade.exceptions.ApplicationException;
import facade.handlers.ProcessOrderHandlerRemote;

@Stateless
public class EncomendarProdutoAction extends Action {
	
	@EJB private ProcessOrderHandlerRemote processOrderHandler;
	
	@Override
	public void process(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException, SQLException {

		EncomendasModel model = createModel(request);
		request.setAttribute("model", model);
		
		if (validInput(model)) {
			try {
				processOrderHandler.newOrder(intValue(model.getvatc()), 
						intValue(model.getprodCode()), doubleValue(model.getqty_order()));
				model.clearFields();
				model.addMessage("Order successfully added.");
			} catch (ApplicationException e) {
				model.addMessage("Error adding order: " + e.getMessage());
			}
		} else
			model.addMessage("Error validating customer data");
		
		request.getRequestDispatcher("/encomendas/encomendaProduto.jsp").forward(request, response);
	}

	private boolean validInput(EncomendasModel model) {
		
		// check if VAT NUMBER is filled and a vaild number
		boolean result = isFilled(model, model.getvatc(), "VAT number must be filled")
	 			&& isInt(model, model.getvatc(), "VAT number with invalid characters");
		
		// check if Product Code is filled and a valid number
		result &= isFilled(model, model.getprodCode(), "Product Code must be filled")
				 			&& isInt(model, model.getprodCode(), "Product Code with invalid characters");
		
		// check if Product Code is filled and a valid number
		result &= isFilled(model, model.getqty_order(), "Quantity must be filled")
							&& isDouble(model, model.getqty_order(), "Quantity with invalid characters");
		return result;
	}

	private EncomendasModel createModel(HttpServletRequest request) {
		// Create the object model
		EncomendasModel model = new EncomendasModel();
		model.setProcessOrderHandler(processOrderHandler);

		// fill it with data from the request
		model.setvatc(request.getParameter("vatc"));
		model.setprodCode(request.getParameter("prodCode"));
		model.setqty_order(request.getParameter("qty_order"));
		
		return model;
	}	
}
