package controller.web.inputController.actions;

import java.io.IOException;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import presentation.web.model.RecepProdutoModel;
import facade.handlers.ProcessOrderHandlerRemote;


/**
 * 
 * @author fmartins
 *
 */
@Stateless
public class RecepProdutoAction extends Action {
	
	@EJB private ProcessOrderHandlerRemote processOrderHandler;

	@Override
	public void process(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		RecepProdutoModel model = new RecepProdutoModel();
		model.setProcessOrderHandler(processOrderHandler);
		request.setAttribute("model", model);
		request.getRequestDispatcher("/encomendas/recepProduto.jsp").forward(request, response);
	}

}
