package controller.web.inputController.actions;

import java.io.IOException;
import java.sql.SQLException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import facade.handlers.ProcessSaleHandlerRemote;
import presentation.web.model.NewSaleModel;

public class NewSaleAction extends Action {

	@EJB private ProcessSaleHandlerRemote processSaleHandler;
	
	@Override
	public void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		NewSaleModel model = new NewSaleModel();
		model.setProcessSaleHandler(processSaleHandler);
		request.setAttribute("model", model);
		request.getRequestDispatcher("/vendas/newSale.jsp").forward(request, response);
	}

}
