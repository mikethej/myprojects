package controller.web.inputController.actions;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import presentation.web.model.ConsultaProdutoModel;
import facade.dto.OrderDTO;
import facade.exceptions.ApplicationException;
import facade.handlers.ProcessOrderHandlerRemote;

@Stateless
public class ConsultarProdutoAction extends Action {

	@EJB private ProcessOrderHandlerRemote processOrderHandler;

	@Override
	public void process(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException, SQLException {

		ConsultaProdutoModel model = createModel(request);
		request.setAttribute("model", model);

		if (validInput(model)) {
			try {
				List<OrderDTO> lista = processOrderHandler.pendingOrders(intValue(model.getid()));
				model.clearFields();
				model.addMessage(IterableOrdersToString(lista));
			} catch (ApplicationException e) {
				model.addMessage("Error searching for order: " + e.getMessage());
			}
		} else
			model.addMessage("Error validating order data");

		request.getRequestDispatcher("/encomendas/consultaProduto.jsp").forward(request, response);
	}

	private boolean validInput(ConsultaProdutoModel model) {

		// check if prod_cod is filled and a valid number
		boolean result = isFilled(model, model.getid(), "ID must be filled")
				&& isInt(model, model.getid(), "ID with invalid characters");

		return result;
	}
	private String IterableOrdersToString(List<OrderDTO> orders) {
		String orderss = "";
		for(OrderDTO order: orders){
			if (orderss == ""){
				orderss += "<p> Vat Fornecedor: " + order.getProviderVat() + "</p>"
						+ "<p>------------------------------------------</p>";
			}
			orderss += "<p> ID da encomenda: "+ order.getId() + "</p> "
					+ "<p>" + "Codigo do Produto: " + order.getProdCode() + "</p>"
					+ "<p>" + "Quantidade Pendente" + order.getQty_pend() + "</p>" 
					+ "<p>------------------------------------------</p>";
		}
		return orderss;
	}

	private ConsultaProdutoModel createModel(HttpServletRequest request) {
		// Create the object model
		ConsultaProdutoModel model = new ConsultaProdutoModel();
		model.setProcessOrderHandler(processOrderHandler);

		// fill it with data from the request
		model.setid(request.getParameter("id"));

		return model;
	}	
}
