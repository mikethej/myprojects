package presentation.web.model;

import facade.handlers.ProcessOrderHandlerRemote;


public class EncomendasModel extends Model {

	private String vatc;
	private String prodCode;
	private String qty_order;
	
	private ProcessOrderHandlerRemote processOrderHandler;
	
	public void setProcessOrderHandler(ProcessOrderHandlerRemote processOrderHandler) {
		this.processOrderHandler = processOrderHandler;
	}
	
	public ProcessOrderHandlerRemote getProcessOrderHandler(){
		return processOrderHandler;
	}
	
	public void setvatc(String vatc) {
		this.vatc = vatc;
	}
	
	public void setprodCode(String prodCode) {
		this.prodCode = prodCode;
	}
	
	public void setqty_order(String qty_order) {
		this.qty_order = qty_order;
	}
	
	public String getvatc() {
		return vatc;
	}
	
	public String getprodCode() {
		return prodCode;
	}	

	public String getqty_order() {
		return qty_order;
	}
	public void clearFields() {
		prodCode = vatc = qty_order = "";
	}
}