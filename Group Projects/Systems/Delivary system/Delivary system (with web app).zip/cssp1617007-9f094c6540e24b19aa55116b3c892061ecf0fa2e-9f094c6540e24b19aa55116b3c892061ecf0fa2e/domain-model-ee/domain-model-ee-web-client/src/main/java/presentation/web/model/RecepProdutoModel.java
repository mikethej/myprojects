package presentation.web.model;

import facade.handlers.ProcessOrderHandlerRemote;

public class RecepProdutoModel extends Model {

	private String vatc;
	private String prodCod;
	private String qty_recv;
	private ProcessOrderHandlerRemote processOrderHandler;
	
	public void setProcessOrderHandler(ProcessOrderHandlerRemote processOrderHandler){
		this.processOrderHandler = processOrderHandler;
	}
	public ProcessOrderHandlerRemote getProcessOrderHandler(){
		return processOrderHandler;
	}
	
	public void setvatc(String vatc){
		this.vatc = vatc;
	}
	
	public void setProdCod(String prodCod){
		this.prodCod = prodCod;
	}
	
	public void setqty_recv(String qty_recv){
		this.qty_recv = qty_recv;
	}
	
	public String getvatc(){
		return vatc;
	}
	
	public String getprodCod(){
		return prodCod;
	}
	public String getqty_recv(){
		return qty_recv;
	}
	
	public void clearFields() {
		vatc = prodCod = qty_recv = "";
	}
}
