package controller.web.inputController.actions;

import java.io.IOException;
import java.sql.SQLException;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import facade.exceptions.ApplicationException;
import facade.handlers.ProcessOrderHandlerRemote;
import presentation.web.model.RecepProdutoModel;

@Stateless
public class ReceptionProdutoAction extends Action {

@EJB private ProcessOrderHandlerRemote processOrderHandler;
	
	@Override
	public void process(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException, SQLException {

		RecepProdutoModel model = createModel(request);
		request.setAttribute("model", model);
		
		if (validInput(model)) {
			try {
				processOrderHandler.recvOrder(intValue(model.getprodCod()), 
						intValue(model.getvatc()), doubleValue(model.getqty_recv()));
				model.clearFields();
				model.addMessage("Product received with success.");
			} catch (ApplicationException e) {
				model.addMessage("Error receving product: " + e.getMessage());
			}
		} else
			model.addMessage("Error validating product data");
		
		request.getRequestDispatcher("/encomendas/recepProduto.jsp").forward(request, response);
	}

	private boolean validInput(RecepProdutoModel model) {
		
		// check if VAT NUMBER is filled and a valid number
		boolean result = isFilled(model, model.getvatc(), "VAT number must be filled")
	 			&& isInt(model, model.getvatc(), "VAT number with invalid characters");
		
		// check if Product Code is filled and a valid number
		result &= isFilled(model, model.getprodCod(), "Product Code must be filled")
				 			&& isInt(model, model.getprodCod(), "Product Code with invalid characters");
		
		// check if Product Code is filled and a valid number
		result &= isFilled(model, model.getqty_recv(), "Quantity must be filled")
							&& isDouble(model, model.getqty_recv(), "Quantity with invalid characters");
		return result;
	}

	private RecepProdutoModel createModel(HttpServletRequest request) {
		// Create the object model
		RecepProdutoModel model = new RecepProdutoModel();
		model.setProcessOrderHandler(processOrderHandler);

		// fill it with data from the request
		model.setProdCod(request.getParameter("prodCod"));
		model.setvatc(request.getParameter("vatc"));
		model.setqty_recv(request.getParameter("qty_recv"));
	
		return model;
	}
}
