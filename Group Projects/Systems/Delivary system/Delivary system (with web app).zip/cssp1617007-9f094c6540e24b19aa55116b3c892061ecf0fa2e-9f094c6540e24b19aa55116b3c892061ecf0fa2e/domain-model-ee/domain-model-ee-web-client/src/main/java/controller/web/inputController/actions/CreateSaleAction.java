package controller.web.inputController.actions;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import facade.exceptions.ApplicationException;
import facade.handlers.ProcessSaleHandlerRemote;
import presentation.web.model.NewSaleModel;

public class CreateSaleAction extends Action{

	@EJB private ProcessSaleHandlerRemote processSaleHandler;
	
	@Override
	public void process(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		NewSaleModel model = createModel(request);
		request.setAttribute("model", model);
		
		if (validInput(model)) {
			try {
				processSaleHandler.newSale(intValue(model.vatNumber()));
				model.clearFields();
				model.addMessage("Sale successfully added.");
			} catch (ApplicationException e) {
				model.addMessage("Error adding sale: " + e.getMessage());
			}
		} else
			model.addMessage("Error validating customer data");
		
		request.getRequestDispatcher("/addCustomer/newCustomer.jsp").forward(request, response);
	}

	private boolean validInput(NewSaleModel model) {
		
		// check if VATNumber is filled and a valid number
		boolean result = isFilled(model, model.vatNumber(), "VAT number must be filled")
				 			&& isInt(model, model.vatNumber(), "VAT number with invalid characters");
		return result;
	}

	private NewSaleModel createModel(HttpServletRequest request) {
		// Create the object model
		NewSaleModel model = new NewSaleModel();
		model.setProcessSaleHandler(processSaleHandler);

		// fill it with data from the request
		model.setVatNumber(request.getParameter("vat"));
		
		return model;
	}
}