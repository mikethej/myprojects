
package business;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for orderDTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="orderDTO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="date" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="date_antiga" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="id_orig" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="prodCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="qty_order" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="qty_pend" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="status" type="{http://business/}orderStatus" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "orderDTO", propOrder = {
    "date",
    "dateAntiga",
    "id",
    "idOrig",
    "prodCode",
    "qtyOrder",
    "qtyPend",
    "status"
})
public class OrderDTO {

    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar date;
    @XmlElement(name = "date_antiga")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dateAntiga;
    protected int id;
    @XmlElement(name = "id_orig")
    protected int idOrig;
    protected int prodCode;
    @XmlElement(name = "qty_order")
    protected double qtyOrder;
    @XmlElement(name = "qty_pend")
    protected double qtyPend;
    @XmlSchemaType(name = "string")
    protected OrderStatus status;

    /**
     * Gets the value of the date property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDate() {
        return date;
    }

    /**
     * Sets the value of the date property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDate(XMLGregorianCalendar value) {
        this.date = value;
    }

    /**
     * Gets the value of the dateAntiga property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateAntiga() {
        return dateAntiga;
    }

    /**
     * Sets the value of the dateAntiga property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateAntiga(XMLGregorianCalendar value) {
        this.dateAntiga = value;
    }

    /**
     * Gets the value of the id property.
     * 
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setId(int value) {
        this.id = value;
    }

    /**
     * Gets the value of the idOrig property.
     * 
     */
    public int getIdOrig() {
        return idOrig;
    }

    /**
     * Sets the value of the idOrig property.
     * 
     */
    public void setIdOrig(int value) {
        this.idOrig = value;
    }

    /**
     * Gets the value of the prodCode property.
     * 
     */
    public int getProdCode() {
        return prodCode;
    }

    /**
     * Sets the value of the prodCode property.
     * 
     */
    public void setProdCode(int value) {
        this.prodCode = value;
    }

    /**
     * Gets the value of the qtyOrder property.
     * 
     */
    public double getQtyOrder() {
        return qtyOrder;
    }

    /**
     * Sets the value of the qtyOrder property.
     * 
     */
    public void setQtyOrder(double value) {
        this.qtyOrder = value;
    }

    /**
     * Gets the value of the qtyPend property.
     * 
     */
    public double getQtyPend() {
        return qtyPend;
    }

    /**
     * Sets the value of the qtyPend property.
     * 
     */
    public void setQtyPend(double value) {
        this.qtyPend = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link OrderStatus }
     *     
     */
    public OrderStatus getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrderStatus }
     *     
     */
    public void setStatus(OrderStatus value) {
        this.status = value;
    }

}
