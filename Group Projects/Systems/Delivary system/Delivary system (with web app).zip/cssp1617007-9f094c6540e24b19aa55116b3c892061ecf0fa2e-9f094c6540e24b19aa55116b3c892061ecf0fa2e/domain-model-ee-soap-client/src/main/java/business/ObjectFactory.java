
package business;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the business package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _NewSaleResponse_QNAME = new QName("http://business/", "newSaleResponse");
    private final static QName _ApplicationException_QNAME = new QName("http://business/", "ApplicationException");
    private final static QName _GetAllProducts_QNAME = new QName("http://business/", "getAllProducts");
    private final static QName _GetAllProductsResponse_QNAME = new QName("http://business/", "getAllProductsResponse");
    private final static QName _NewSale_QNAME = new QName("http://business/", "newSale");
    private final static QName _AddProductToSale_QNAME = new QName("http://business/", "addProductToSale");
    private final static QName _CloseSaleResponse_QNAME = new QName("http://business/", "closeSaleResponse");
    private final static QName _GetSaleDiscount_QNAME = new QName("http://business/", "getSaleDiscount");
    private final static QName _AddProductToSaleResponse_QNAME = new QName("http://business/", "addProductToSaleResponse");
    private final static QName _CloseSale_QNAME = new QName("http://business/", "closeSale");
    private final static QName _AnnulSale_QNAME = new QName("http://business/", "annulSale");
    private final static QName _AnnulSaleResponse_QNAME = new QName("http://business/", "annulSaleResponse");
    private final static QName _GetCurrentSale_QNAME = new QName("http://business/", "getCurrentSale");
    private final static QName _GetSaleTotal_QNAME = new QName("http://business/", "getSaleTotal");
    private final static QName _GetSaleTotalResponse_QNAME = new QName("http://business/", "getSaleTotalResponse");
    private final static QName _GetCurrentSaleResponse_QNAME = new QName("http://business/", "getCurrentSaleResponse");
    private final static QName _GetSaleDiscountResponse_QNAME = new QName("http://business/", "getSaleDiscountResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: business
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetCurrentSale }
     * 
     */
    public GetCurrentSale createGetCurrentSale() {
        return new GetCurrentSale();
    }

    /**
     * Create an instance of {@link CloseSale }
     * 
     */
    public CloseSale createCloseSale() {
        return new CloseSale();
    }

    /**
     * Create an instance of {@link AnnulSale }
     * 
     */
    public AnnulSale createAnnulSale() {
        return new AnnulSale();
    }

    /**
     * Create an instance of {@link AnnulSaleResponse }
     * 
     */
    public AnnulSaleResponse createAnnulSaleResponse() {
        return new AnnulSaleResponse();
    }

    /**
     * Create an instance of {@link GetCurrentSaleResponse }
     * 
     */
    public GetCurrentSaleResponse createGetCurrentSaleResponse() {
        return new GetCurrentSaleResponse();
    }

    /**
     * Create an instance of {@link GetSaleDiscountResponse }
     * 
     */
    public GetSaleDiscountResponse createGetSaleDiscountResponse() {
        return new GetSaleDiscountResponse();
    }

    /**
     * Create an instance of {@link GetSaleTotalResponse }
     * 
     */
    public GetSaleTotalResponse createGetSaleTotalResponse() {
        return new GetSaleTotalResponse();
    }

    /**
     * Create an instance of {@link GetSaleTotal }
     * 
     */
    public GetSaleTotal createGetSaleTotal() {
        return new GetSaleTotal();
    }

    /**
     * Create an instance of {@link GetAllProducts }
     * 
     */
    public GetAllProducts createGetAllProducts() {
        return new GetAllProducts();
    }

    /**
     * Create an instance of {@link ApplicationException }
     * 
     */
    public ApplicationException createApplicationException() {
        return new ApplicationException();
    }

    /**
     * Create an instance of {@link NewSaleResponse }
     * 
     */
    public NewSaleResponse createNewSaleResponse() {
        return new NewSaleResponse();
    }

    /**
     * Create an instance of {@link AddProductToSaleResponse }
     * 
     */
    public AddProductToSaleResponse createAddProductToSaleResponse() {
        return new AddProductToSaleResponse();
    }

    /**
     * Create an instance of {@link GetSaleDiscount }
     * 
     */
    public GetSaleDiscount createGetSaleDiscount() {
        return new GetSaleDiscount();
    }

    /**
     * Create an instance of {@link NewSale }
     * 
     */
    public NewSale createNewSale() {
        return new NewSale();
    }

    /**
     * Create an instance of {@link AddProductToSale }
     * 
     */
    public AddProductToSale createAddProductToSale() {
        return new AddProductToSale();
    }

    /**
     * Create an instance of {@link CloseSaleResponse }
     * 
     */
    public CloseSaleResponse createCloseSaleResponse() {
        return new CloseSaleResponse();
    }

    /**
     * Create an instance of {@link GetAllProductsResponse }
     * 
     */
    public GetAllProductsResponse createGetAllProductsResponse() {
        return new GetAllProductsResponse();
    }

    /**
     * Create an instance of {@link ProductDTO }
     * 
     */
    public ProductDTO createProductDTO() {
        return new ProductDTO();
    }

    /**
     * Create an instance of {@link Unit }
     * 
     */
    public Unit createUnit() {
        return new Unit();
    }

    /**
     * Create an instance of {@link Sale }
     * 
     */
    public Sale createSale() {
        return new Sale();
    }

    /**
     * Create an instance of {@link Customer }
     * 
     */
    public Customer createCustomer() {
        return new Customer();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NewSaleResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business/", name = "newSaleResponse")
    public JAXBElement<NewSaleResponse> createNewSaleResponse(NewSaleResponse value) {
        return new JAXBElement<NewSaleResponse>(_NewSaleResponse_QNAME, NewSaleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplicationException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business/", name = "ApplicationException")
    public JAXBElement<ApplicationException> createApplicationException(ApplicationException value) {
        return new JAXBElement<ApplicationException>(_ApplicationException_QNAME, ApplicationException.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllProducts }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business/", name = "getAllProducts")
    public JAXBElement<GetAllProducts> createGetAllProducts(GetAllProducts value) {
        return new JAXBElement<GetAllProducts>(_GetAllProducts_QNAME, GetAllProducts.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllProductsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business/", name = "getAllProductsResponse")
    public JAXBElement<GetAllProductsResponse> createGetAllProductsResponse(GetAllProductsResponse value) {
        return new JAXBElement<GetAllProductsResponse>(_GetAllProductsResponse_QNAME, GetAllProductsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NewSale }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business/", name = "newSale")
    public JAXBElement<NewSale> createNewSale(NewSale value) {
        return new JAXBElement<NewSale>(_NewSale_QNAME, NewSale.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddProductToSale }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business/", name = "addProductToSale")
    public JAXBElement<AddProductToSale> createAddProductToSale(AddProductToSale value) {
        return new JAXBElement<AddProductToSale>(_AddProductToSale_QNAME, AddProductToSale.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CloseSaleResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business/", name = "closeSaleResponse")
    public JAXBElement<CloseSaleResponse> createCloseSaleResponse(CloseSaleResponse value) {
        return new JAXBElement<CloseSaleResponse>(_CloseSaleResponse_QNAME, CloseSaleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSaleDiscount }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business/", name = "getSaleDiscount")
    public JAXBElement<GetSaleDiscount> createGetSaleDiscount(GetSaleDiscount value) {
        return new JAXBElement<GetSaleDiscount>(_GetSaleDiscount_QNAME, GetSaleDiscount.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddProductToSaleResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business/", name = "addProductToSaleResponse")
    public JAXBElement<AddProductToSaleResponse> createAddProductToSaleResponse(AddProductToSaleResponse value) {
        return new JAXBElement<AddProductToSaleResponse>(_AddProductToSaleResponse_QNAME, AddProductToSaleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CloseSale }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business/", name = "closeSale")
    public JAXBElement<CloseSale> createCloseSale(CloseSale value) {
        return new JAXBElement<CloseSale>(_CloseSale_QNAME, CloseSale.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AnnulSale }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business/", name = "annulSale")
    public JAXBElement<AnnulSale> createAnnulSale(AnnulSale value) {
        return new JAXBElement<AnnulSale>(_AnnulSale_QNAME, AnnulSale.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AnnulSaleResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business/", name = "annulSaleResponse")
    public JAXBElement<AnnulSaleResponse> createAnnulSaleResponse(AnnulSaleResponse value) {
        return new JAXBElement<AnnulSaleResponse>(_AnnulSaleResponse_QNAME, AnnulSaleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCurrentSale }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business/", name = "getCurrentSale")
    public JAXBElement<GetCurrentSale> createGetCurrentSale(GetCurrentSale value) {
        return new JAXBElement<GetCurrentSale>(_GetCurrentSale_QNAME, GetCurrentSale.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSaleTotal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business/", name = "getSaleTotal")
    public JAXBElement<GetSaleTotal> createGetSaleTotal(GetSaleTotal value) {
        return new JAXBElement<GetSaleTotal>(_GetSaleTotal_QNAME, GetSaleTotal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSaleTotalResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business/", name = "getSaleTotalResponse")
    public JAXBElement<GetSaleTotalResponse> createGetSaleTotalResponse(GetSaleTotalResponse value) {
        return new JAXBElement<GetSaleTotalResponse>(_GetSaleTotalResponse_QNAME, GetSaleTotalResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCurrentSaleResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business/", name = "getCurrentSaleResponse")
    public JAXBElement<GetCurrentSaleResponse> createGetCurrentSaleResponse(GetCurrentSaleResponse value) {
        return new JAXBElement<GetCurrentSaleResponse>(_GetCurrentSaleResponse_QNAME, GetCurrentSaleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSaleDiscountResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://business/", name = "getSaleDiscountResponse")
    public JAXBElement<GetSaleDiscountResponse> createGetSaleDiscountResponse(GetSaleDiscountResponse value) {
        return new JAXBElement<GetSaleDiscountResponse>(_GetSaleDiscountResponse_QNAME, GetSaleDiscountResponse.class, null, value);
    }

}
