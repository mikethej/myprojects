@javax.xml.bind.annotation.XmlSchema(namespace = "http://business/")
package business;
