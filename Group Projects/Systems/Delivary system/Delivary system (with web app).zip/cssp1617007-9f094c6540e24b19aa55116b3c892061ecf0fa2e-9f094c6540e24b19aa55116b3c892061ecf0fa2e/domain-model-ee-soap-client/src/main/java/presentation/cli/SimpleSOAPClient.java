package presentation.cli;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import business.AddCustomerHandler;
import business.AddCustomerHandlerService;
import business.ApplicationException_Exception;
import business.Orders;
import business.ProcessOrderHandler;
import business.ProcessOrderHandlerService;
import business.SQLException_Exception;

/**
 * A simple application client that uses both services.
 *	
 * @author fmartins
 * @version 1.2 (11/02/2015)
 * 
 */
public class SimpleSOAPClient {

	private static int vat;
	private static String denomination;
	private static int phoneNumber;
	private static int vatc;
	private static String prodCode;
	private static double qty;
	private static String qty_recv;
	private static String resp;
	private static String nOrder;
	private static BufferedReader keyboard;
	private static int discount;

	/**
	 * A simple interaction with the application services
	 * 
	 * @param args Command line parameters
	 * @throws SQLException_Exception 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, SQLException_Exception {
		
		try{
			BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
			System.out.println(
				  "|-------------------------|\n"
				+ "|                         |\n"
				+ "|   Welcome to SaleSys!   |\n" 
				+ "|                         |");
			String option;
			while(true){
				System.out.println(
						  "|-------------------------|\n" 
						+ "| What do you wish to do? |\n"
						+ "|-------------------------|\n" 
						+ "|1: Add Client            |\n"
						+ "|2: Order Products        |\n" 
						+ "|3: Order Reception       |\n"
						+ "|4: Pending Orders        |\n" 
						+ "|5: Exit                  |\n"
						+ "|-------------------------|");
				System.out.print("Option: ");
				option = bufferRead.readLine();
				switch (option){
				case "1":
					System.out.println("Add client selected!\nEnter the corresponding data:");
					System.out.print("VAT: ");
					vat = Integer.parseInt(bufferRead.readLine());
					System.out.println("Denomination: ");
					denomination = bufferRead.readLine();
					System.out.println("Phone Number: ");
					phoneNumber = Integer.parseInt(bufferRead.readLine());
					System.out.println("Discount: ");
					discount = Integer.parseInt(bufferRead.readLine());
					// Make a service
				    AddCustomerHandlerService service = new AddCustomerHandlerService();
				    // Now use the service to get a stub which implements the SDI.
				    AddCustomerHandler customerHandler = service.getAddCustomerHandlerPort();
				    // Make the actual call
				    try {
						customerHandler.addCustomer(vat, denomination, phoneNumber, discount);
						System.out.println("Cliente adiciondo com sucesso.");
					} catch (ApplicationException_Exception e) {
						System.out.println("Erro ao adicionar cliente.");
						System.out.println("Causa:");
						e.printStackTrace();
					}
				    break;
				case "2":
					System.out.println("Order Products selected!\nEnter the corresponding data:");
					System.out.print("Number of provider: ");
					vatc = Integer.parseInt(bufferRead.readLine());
					System.out.println("Product Code: ");
					prodCode = bufferRead.readLine();
					System.out.println("Quantity: ");
					qty = Double.parseDouble(bufferRead.readLine());
					ProcessOrderHandlerService orderService = new ProcessOrderHandlerService();
					ProcessOrderHandler orderHandler = orderService.getProcessOrderHandlerPort();
					try{
						orderHandler.newOrder(vatc, Integer.parseInt(prodCode), qty);
					} catch(ApplicationException_Exception e){
						System.out.println("Erro ao adicionar encomenda");
						System.out.println("Causa:");
						e.printStackTrace();
					}
					break;
				case "3":
					System.out.println("Order Reception selected!\nEnter the corresponding data:");
					System.out.print("Number of provider: ");
					vatc = Integer.parseInt(bufferRead.readLine());
					System.out.println("Orders:");
					ProcessOrderHandlerService order5Service = new ProcessOrderHandlerService();
					ProcessOrderHandler order5Handler = order5Service.getProcessOrderHandlerPort();
					Orders order = order5Handler.getCurrentOrder();
					System.out.println("Product Code: ");
					prodCode = bufferRead.readLine();
					double qty_order = order.getQtyOrder();
					do{
						System.out.println("Quantity: ");
						qty_recv = bufferRead.readLine();
						if (Double.parseDouble(qty_recv) >= qty_order){
							System.out.println("Quantity bigger than order");
						}
					} while (Double.parseDouble(qty_recv) >= qty_order);
					try{
						order5Handler.receiveOrder(Integer.parseInt(prodCode), vatc, qty_order);
					} catch(ApplicationException_Exception e){
						System.out.println("Erro ao receber encomenda");
						System.out.println("Causa:");
						e.printStackTrace();
					}
					break;
				case "4":
					System.out.println("Pending Orders selected!\nEnter the corresponding data:");
					System.out.println("Product Code: ");
					prodCode = bufferRead.readLine();
					boolean cenas = false;
					do {
						System.out.println("Do you want to see the Pending Orders?");
						resp = bufferRead.readLine();
						if (resp.equals("yes")||resp.equals("Y")||resp.equals("Yes")||resp.equals("y")||resp.equals("YES")) {
							System.out.println("Number of Order: ");
							nOrder = bufferRead.readLine();
							ProcessOrderHandlerService order6Service = new ProcessOrderHandlerService();
							ProcessOrderHandler order6Handler = order6Service.getProcessOrderHandlerPort();
							try{
								order6Handler.pendingOrders(Integer.parseInt(nOrder));
							} catch(ApplicationException_Exception e){
								System.out.println("Erro ao ver as encomendas pendentes");
								System.out.println("Causa:");
								e.printStackTrace();
							}
						}
					} while(cenas);
					break;
				case "5":
					System.out.print("Exiting.");
					Thread.sleep(1000);
					System.out.print(".");
					Thread.sleep(1000);
					System.out.print(".");
					Thread.sleep(1000);
					bufferRead.close();
					try {
						keyboard.close();
					} catch (NullPointerException e) {
					}
					System.exit(0);
				default:
					System.out.println("The option chosen is invalid!");
					break;
				}
				System.out.println("\n\n\n\n\n");
			}
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
	}
}