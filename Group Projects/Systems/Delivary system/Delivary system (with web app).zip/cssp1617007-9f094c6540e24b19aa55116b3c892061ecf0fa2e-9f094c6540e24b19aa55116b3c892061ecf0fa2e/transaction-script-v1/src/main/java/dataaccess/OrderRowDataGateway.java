package dataaccess;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;

import business.OrderStatus;

public class OrderRowDataGateway {
	private int vatc;
	private int id;
	private int prodCode;
	private double qty_pend;
	private int og_id;
	private java.sql.Date date_recv = new java.sql.Date(Calendar.getInstance().getTimeInMillis() + (1000*60*60*24*7));
	private java.sql.Date date_order = new java.sql.Date(Calendar.getInstance().getTimeInMillis());
	private String designacao;
	private double qty_order;
	private String status;
	
	private static final String PENDENT = "P";
	private static final String RECEIVE = "R";
	//private static final String PARCIAL = "L";
	
	public OrderRowDataGateway(int vatc, int prodCode, double qty){
		this.qty_pend = qty;
		this.vatc = vatc;
		this.prodCode = prodCode;
		this.qty_order = qty;
		this.og_id = 0;
	}
	public int getId() {
		return id;
	}
	public int getProviderId(){
		return vatc;
	}
	public int getProductCode(){
		return prodCode;
	}
	public double getQuantityPend(){
		return qty_pend;
	}
	public void setQuantityPend(double qty){
		qty_pend = qty;
	}
	public double getQuantity(){
		return qty_order;
	}
	public String designation(){
		return designacao;
	}
	public int getOriginalId(){
		return og_id;
	}
	public OrderStatus getStatus() {
		if(status.equals(PENDENT)) {
			return OrderStatus.PENDENT;
		} 
		else{
			if(status.equals(RECEIVE)) {
				return OrderStatus.RECEIVE;
			}
			else{
				return OrderStatus.PARCIAL;
			}
		}
	}
	
	/**
	 * The insert sale SQL statement
	 */
	private static final String INSERT_ORDER_SQL = 
			"insert into orderprod (id, id_o, designation, vatc, product_code, qty_pend, qty_order, date_order, date_recv, date_estim, status) " + 
			"values (DEFAULT, 0, ?, ?, ?, ?, ?, ?, NULL, ?, 'P')";

	/**
	 * Stores the information in the repository
	 */
	public void insert (int vatc, int prodCode, double qty, String designation) throws PersistenceException {		
		try (PreparedStatement statement = DataSource.INSTANCE.prepareGetGenKey(INSERT_ORDER_SQL)) {
			// set statement arguments
			//statement.setInt(1, og_id);
			setQuantityPend(qty);
			statement.setString(1, designacao);
			statement.setInt(2, vatc);
			statement.setInt(3, prodCode);
			statement.setDouble(4, qty_pend);
			statement.setDouble(5, qty);
			statement.setDate(6, date_order);
			//new java.sql.Date(Calendar.getInstance().getTimeInMillis())
			statement.setDate(7, date_recv);
			// executes SQL
			statement.executeUpdate();
			// Gets customer Id generated automatically by the database engine
			try (ResultSet rs = statement.getGeneratedKeys()) {
				rs.next();
				id = rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new PersistenceException ("Internal error!", e);
		}
	}
	
	/**
	 * The select customer by VAT SQL statement
	 */
	private static final String GET_ORDER_BY_VAT_NUMBER_SQL = "select * from orderprod where vatc = ?";
	/**
	 * Fetches a customer given its VAT number and returns a CustomerRowGateway 
	 * object with the data retrieved from the database. In case the customer
	 * is not found, a RecordNotFoundException is thrown. I use a static method
	 * for processing the result set and for creating the Customer Row Gateway 
	 * object. This way I avoid repeating the code in the methods implementing
	 * various forms of obtaining records from the database.
	 * 
	 * @param vat The VAT number of the customer to fetch from the database
	 * @return The CustomerRowGateway corresponding to the customer with the vat number.
	 * @throws RecordNotFoundException When the customer with the vat number is not found.
	 */
	public static OrderRowDataGateway getOrderByVATNumber (int vat) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_ORDER_BY_VAT_NUMBER_SQL)) {			
			// set statement arguments
			statement.setInt(1, vat);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				// creates a new customer from the data retrieved from the database
				OrderRowDataGateway newOrder = null;
				while(rs.next()){
					newOrder = new OrderRowDataGateway(rs.getInt("vatc"), rs.getInt("product_code"),rs.getDouble("qty_pend"));
					newOrder.id = rs.getInt(1);
					newOrder.date_order = rs.getDate(8);
					newOrder.qty_order = rs.getDouble(7);
					newOrder.date_recv = rs.getDate(9);
					newOrder.designacao= rs.getString(3);
					newOrder.og_id = rs.getInt(2);
					newOrder.status = rs.getString(11);
					System.out.println("Product Code: " + newOrder.getProductCode());
					System.out.println("Quantity Pendent: " + newOrder.getQuantityPend());
				}
				return newOrder;
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a customer by its VATc", e);
		} 
	}
	private static final String GET_ID_BY_VAT_NUMBER_SQL = "select * from orderprod where vatc = ?";
	/**
	 * Fetches a customer given its VAT number and returns a CustomerRowGateway 
	 * object with the data retrieved from the database. In case the customer
	 * is not found, a RecordNotFoundException is thrown. I use a static method
	 * for processing the result set and for creating the Customer Row Gateway 
	 * object. This way I avoid repeating the code in the methods implementing
	 * various forms of obtaining records from the database.
	 * 
	 * @param vat The VAT number of the customer to fetch from the database
	 * @return The CustomerRowGateway corresponding to the customer with the vat number.
	 * @throws RecordNotFoundException When the customer with the vat number is not found.
	 */
	public int getIdByVATNumber (int vat) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_ID_BY_VAT_NUMBER_SQL)) {			
			// set statement arguments
			statement.setInt(1, vat);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				// creates a new customer from the data retrieved from the database
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a customer by its VAT number", e);
		} 
	}
	
	private static final String GET_ID_BY_PROD_CODE_SQL = "select * from orderprod where vatc = ?";
	
	public int getIdByProdCode (int prodCode) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare( GET_ID_BY_PROD_CODE_SQL)) {			
			// set statement arguments
			statement.setInt(1, prodCode);
			// executes SQL
			//statement.executeQuery();
			try (ResultSet rs = statement.executeQuery()) {
				// creates a new customer from the data retrieved from the database
				rs.next();
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a customer by its VAT number", e);
		} 
	}
	
	private static final String GET_ORDER_BY_PROD_CODE_SQL = "select * from orderprod where product_code = ?";
	public static OrderRowDataGateway getOrderByProdCode (int prodCode) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_ORDER_BY_PROD_CODE_SQL)) {			
			// set statement arguments
			statement.setInt(1, prodCode);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				// creates a new customer from the data retrieved from the database
				return loadOrder(rs);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a customer by its VAT number", e);
		} 
	}
	public static ResultSet getOrderByProdCodeRS (int prodCode) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepareGetGenKey(GET_ORDER_BY_PROD_CODE_SQL)) {			
			// set statement arguments
			statement.setInt(1, prodCode);
			// executes SQL
			statement.executeQuery();
			ResultSet rs = statement.getGeneratedKeys();
			return rs;
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a customer by its VAT number", e);
		} 
	}
	
	
	private static final String GET_ORDER_BY_PROD_CODE_PEND_SQL = "select * from orderprod where product_code = ? and (status='P' or status='L')";
	
	public static OrderRowDataGateway getOrderByProdCodePend (int prodCode) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_ORDER_BY_PROD_CODE_PEND_SQL)) {			
			// set statement arguments
			statement.setInt(1, prodCode);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				// creates a new customer from the data retrieved from the database
				return loadOrder(rs);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a customer by its VAT number", e);
		} 
	}
	private static final String GET_ORDER_BY_PROD_CODE_PARCIAL_SQL = "select * from orderprod where id = ? and (status='P' or status='L')";
	
	public static OrderRowDataGateway getOrderByIdParcial(int id) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_ORDER_BY_PROD_CODE_PARCIAL_SQL)) {			
			// set statement arguments
			statement.setInt(1, id);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				// creates a new customer from the data retrieved from the database
				return loadOrder(rs);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a customer by its VAT number", e);
		} 
	}
	
	private static final String GET_DATE_BY_ID_SQL = "select date_order from orderprod where id = ?";
	
	public Date getDatebyId (int id) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_DATE_BY_ID_SQL)) {			
			// set statement arguments
			statement.setInt(1, id);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				// creates a new customer from the data retrieved from the database
				rs.next();
				return rs.getDate("date_order");
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a customer by its date", e);
		} 
	}
	
	private static OrderRowDataGateway loadOrder(ResultSet rs) throws RecordNotFoundException {
		try {
			rs.next();
			OrderRowDataGateway newOrder = new OrderRowDataGateway(rs.getInt(4), 
					rs.getInt(5),rs.getDouble(6));
			newOrder.id = rs.getInt(1);
			newOrder.date_order = rs.getDate(8);
			newOrder.qty_order = rs.getDouble(7);
			newOrder.date_recv = rs.getDate(9);
			newOrder.designacao= rs.getString(3);
			newOrder.og_id = rs.getInt(2);
			newOrder.status = rs.getString(11);
			return newOrder;
		} catch (SQLException e) {
			throw new RecordNotFoundException ("Order does not exist", e);
		}
	}
	
	/**
	 * The insert sale SQL statement
	 */
	private static final String INSERT_ORDER_PEND_SQL = 
			"insert into orderprod (id, id_o, designacao, vatc, product_code, qty_pend, qty_order, date_order, date_recv, date_estim, status) " + 
			"values (DEFAULT, ?, ?, ?, ?, ?, ?, ?, ?, NULL, 'L')";
	
	/**
	 * Stores the information in the repository
	 */
	public void insertPend (int id, Date date_antiga, double qty) throws PersistenceException {		
		try (PreparedStatement statement = DataSource.INSTANCE.prepareGetGenKey(INSERT_ORDER_PEND_SQL)) {
			// set statement arguments
			setQuantityPend(getQuantityPend() - qty);
			statement.setInt(1, id);
			statement.setString(2, designacao);
			statement.setInt(3, vatc);
			statement.setInt(4, prodCode);
			statement.setDouble(5, qty_pend);
			statement.setDouble(6, qty_order);
			statement.setDate(7, (java.sql.Date)date_antiga);
			statement.setDate(8, date_recv);
			//new java.sql.Date(Calendar.getInstance().getTimeInMillis())
			// executes SQL
			statement.executeUpdate();
			// Gets customer Id generated automatically by the database engine
			try (ResultSet rs = statement.getGeneratedKeys()) {
				rs.next();
				id = rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new PersistenceException ("Internal error!", e);
		}
	}
	/**
	 * The update product stock SQL statement
	 */
	private static final String	UPDATE_STATUS_RECV_SQL = 
			"update orderprod set status='R', qty_pend=0 where id = ?";
	
	/**
	 * Updates the product status
	 * 
	 * @throws PersistenceException
	 */
	public void updateStatusRecv () throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(UPDATE_STATUS_RECV_SQL)){
			// set statement arguments
			statement.setInt(1, id);
			// execute SQL
			statement.executeUpdate();
		} catch (SQLException e) {
			throw new PersistenceException("Internal error updating product " + id + " stock amount.", e);
		}
	}
	
	private static final String	UPDATE_DATE_RECV_SQL = "update orderprod set date_recv=? where id = ?";
	
	public void updateDateRecv () throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(UPDATE_DATE_RECV_SQL)){
			// set statement arguments
			statement.setDate(1, new java.sql.Date(date_order.getTime()));
			statement.setInt(2, id);
			// execute SQL
			statement.executeUpdate();
		} catch (SQLException e) {
			throw new PersistenceException("Internal error updating product " + id + " stock amount.", e);
		}
	}
	
	/**
	 * The update product stock SQL statement
	 */
	private static final String	UPDATE_STATUS_PARCIAL_SQL = 
			"update product set status='L', qty_pend=? where id = ?";
	
	/**
	 * Updates the product quantity
	 * 
	 * @throws PersistenceException
	 */
	public void updateStatusParcial (int qty) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(UPDATE_STATUS_PARCIAL_SQL)){
			// set statement arguments
			System.out.println("Qty_Pend:  " + getQuantityPend());
			System.out.println("Qty: " + getQuantity());
			setQuantityPend(getQuantityPend()-qty);
			statement.setDouble(1, qty_pend);
			statement.setInt(2, id);
			// execute SQL
			statement.executeUpdate();
		} catch (SQLException e) {
			throw new PersistenceException("Internal error updating product " + id + " stock amount.", e);
		}
	}
}