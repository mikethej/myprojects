package business;

/**
 * 
 * The sale status
 */
public enum OrderStatus {
	PENDENT, RECEIVE, PARCIAL;
}
