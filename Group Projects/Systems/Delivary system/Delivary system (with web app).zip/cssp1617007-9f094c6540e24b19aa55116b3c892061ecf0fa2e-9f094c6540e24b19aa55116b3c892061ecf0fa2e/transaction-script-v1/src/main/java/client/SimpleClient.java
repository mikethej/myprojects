package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;

import dataaccess.CustomerRowDataGateway;
import dataaccess.OrderRowDataGateway;
import dataaccess.PersistenceException;
import dataaccess.ProviderRowDataGateway;
import dataaccess.SaleRowDataGateway;
import SaleSys.SaleSys;
import business.ApplicationException;
import business.CustomerTransactionScripts;
import business.DiscountType;
import business.OrderTransactionScripts;
import business.SaleTransactionScripts;

/**
 * A simple application client that uses both services.
 *	
 * @author fmartins
 * @version 1.2 (11/02/2015)
 * 
 */
public class SimpleClient {
	private static int vat;
	private static String denomination;
	private static int phoneNumber;
	private static String prodCode;
	private static double qty;
	private static BufferedReader keyboard;
	private static int vatc;
	private static String qty_recv;
	private static String nOrder;
	private static String resp;
	private static boolean cenas;
	private static int customerId;
	private static int saleId;
	private static String designation;

	/**
	 * A simple interaction with the application services
	 * 
	 * @param args Command line parameters
	 * @throws SQLException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, SQLException {
		
		SaleSys app = new SaleSys();
		try {
			app.run();
		} catch (ApplicationException e) {
			System.out.println(e.getMessage());
			System.out.println("Application Message: " + e.getMessage());
			SQLException e1 = (SQLException) e.getCause().getCause();
			System.out.println("SQLException: " + e1.getMessage());
			System.out.println("SQLState: " + e1.getSQLState());
			System.out.println("VendorError: " + e1.getErrorCode());
			e.printStackTrace();
			return;	
		}
		try{
			BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("|-------------------------|\n"
				+ "|                         |\n"
				+ "|   Welcome to SaleSys!   |\n" 
				+ "|                         |");
			String option;
			while(true){
				System.out.println(
						  "|-------------------------|\n" 
						+ "| What do you wish to do? |\n"
						+ "|-------------------------|\n" 
						+ "|1: Add Client            |\n"
						+ "|2: New Sale              |\n" 
						+ "|3: Annul Sale            |\n"
						+ "|4: Order Products        |\n" 
						+ "|5: Order Reception       |\n"
						+ "|6: Pending Orders        |\n" 
						+ "|7: Exit                  |\n"
						+ "|-------------------------|");
				System.out.print("Option: ");
				option = bufferRead.readLine();
				switch (option){
				case "1":
					System.out.println("Add client selected!\nEnter the corresponding data:");
					System.out.print("VAT: ");
					vat = Integer.parseInt(bufferRead.readLine());
					System.out.println("Denomination: ");
					denomination = bufferRead.readLine();
					System.out.println("Phone Number: ");
					phoneNumber = Integer.parseInt(bufferRead.readLine());
					CustomerTransactionScripts customerTransactionScripts = new CustomerTransactionScripts();
					customerTransactionScripts.addCustomer(vat, denomination, phoneNumber, DiscountType.SALE_AMOUNT);
					System.out.println("Client added");
					break;
				case "2":
					System.out.println("New Sale selected!\nEnter the corresponding data:");
					System.out.print("VAT: ");
					vat = Integer.parseInt(bufferRead.readLine());
					SaleTransactionScripts saleTransactionScripts = new SaleTransactionScripts();
					saleId = saleTransactionScripts.newSale(vat);
					System.out.println("Write the product code and the quantity (empty values to finish adding products)");
					System.out.println("Product Code: ");
					prodCode = bufferRead.readLine();
					System.out.println("Quantity: ");
					qty = Double.parseDouble(bufferRead.readLine());
					while (!prodCode.equals("")) {
						saleTransactionScripts.addProductToSale(saleId, Integer.parseInt(prodCode), qty);
						System.out.println("Product Code: ");
						prodCode = bufferRead.readLine();
						System.out.println("Quantity: ");
						try{
							qty = Double.parseDouble(bufferRead.readLine());
						} catch(NumberFormatException e){}
					}
					System.out.println("Products added");
					break;
				case "3":
					System.out.println("Annul Sale selected!\nEnter the corresponding data:");
					System.out.print("VAT: ");
					vat = Integer.parseInt(bufferRead.readLine());
					CustomerRowDataGateway customer = CustomerRowDataGateway.getCustomerByVATNumber(vat);
					customerId = customer.getCustomerId();
					SaleRowDataGateway sale = SaleRowDataGateway.getSaleByVAT(customerId);
					saleId = sale.getId();
					SaleTransactionScripts saleTransactionScript = new SaleTransactionScripts();
					saleTransactionScript.annulSale(saleId);
					System.out.println("Sale Annuled");
					break;					
				case "4":
					System.out.println("Order Products selected!\nEnter the corresponding data:");
					System.out.print("Number of provider: ");
					vatc = Integer.parseInt(bufferRead.readLine());
					ProviderRowDataGateway provider = ProviderRowDataGateway.getProviderByVATNumber(vatc);
					designation = provider.getDesignation();
					System.out.println("Designation: " + designation);
					System.out.println("Product Code: ");
					prodCode = bufferRead.readLine();
					System.out.println("Quantity: ");
					qty = Double.parseDouble(bufferRead.readLine());
					OrderTransactionScripts orderTransactionScripts = new OrderTransactionScripts();
					orderTransactionScripts.newOrder(vatc, Integer.parseInt(prodCode), qty, designation);
					System.out.println("Order Checked");
					break;
				case "5":
					System.out.println("Order Reception selected!\nEnter the corresponding data:");
					System.out.print("Number of provider: ");
					vatc = Integer.parseInt(bufferRead.readLine());
					System.out.println("Orders:");
					OrderRowDataGateway order = OrderRowDataGateway.getOrderByVATNumber(vatc);
					System.out.println("Product Code: ");
					prodCode = bufferRead.readLine();
					double qty_order = order.getQuantity();
					do{
						System.out.println("Quantity: ");
						qty_recv = bufferRead.readLine();
						if (Double.parseDouble(qty_recv) >= qty_order){
							System.out.println("Quantity bigger than order");
						}
					}
					while (Double.parseDouble(qty_recv) >= qty_order);
					OrderTransactionScripts orderTransactionScript = new OrderTransactionScripts();
					orderTransactionScript.recvOrder(Integer.parseInt(prodCode) ,vatc, Integer.parseInt(qty_recv));
					System.out.println("Reception Order Checked");
					break;
				case "6":
					try{
						System.out.println("Pending Orders selected!\nEnter the corresponding data:");
						System.out.println("Product Code: ");
						prodCode = bufferRead.readLine();
						OrderRowDataGateway orderL = OrderRowDataGateway.getOrderByProdCodePend(Integer.parseInt(prodCode));
						System.out.println(orderL.getId());
						cenas = true;
						do{
							System.out.println("Do you want to see the Pending Orders?");
							resp = bufferRead.readLine();
							if (resp.equals("yes")||resp.equals("Y")||resp.equals("Yes")||resp.equals("y")||resp.equals("YES")) {
								System.out.println("Number of Order: ");
								nOrder = bufferRead.readLine();
								OrderRowDataGateway parcial = OrderRowDataGateway.getOrderByIdParcial(Integer.parseInt(nOrder));
								if (parcial !=null){
									System.out.print("Receive date: ");
									System.out.println(parcial.getDatebyId(orderL.getId()));
									System.out.print("Quantity: ");
									System.out.println(parcial.getQuantityPend());
								} else{
									System.out.println("This order had no partial delivery");
								}
							}
							else{
								System.out.println("Pending Orders Checked");
								cenas = false;
							}
						} while(cenas);
					} catch (PersistenceException e){
						throw new PersistenceException("No Pending Orders number", e);
					}
					break;
				case "7":
					System.out.print("Exiting.");
					Thread.sleep(1000);
					System.out.print(".");
					Thread.sleep(1000);
					System.out.print(".");
					Thread.sleep(1000);
					bufferRead.close();
					try {
						keyboard.close();
					} catch (NullPointerException e) {
					}
					System.exit(0);
				default:
					System.out.println("The option chosen is invalid!");
					break;
				}
				System.out.println("\n\n\n\n\n");
			}
		} catch (IOException|InterruptedException|ApplicationException|PersistenceException e) {
			e.printStackTrace();
		}
		// the interaction
		app.stopRun();
	}
}