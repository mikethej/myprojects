package dataaccess;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

/**
 * An in-memory representation of a row gateway for the products composing a sale.	
 * 
 * @author 
 * @version 
 *
 */
public class SaleProductRowDataGateway {
	
	// 1. Sale product attributes 
	private int productId;
	private double qty;
	private int id;
	private int saleId;

	// 2. constructor
	public SaleProductRowDataGateway(int saleId, int productId, double qty) {
		this.saleId = saleId;
		this.productId = productId;
		this.qty = qty;
	}
	// 3. getters and setters
	public int getProductId() {
		return productId;
	}

	public double getQty() {
		return qty;
	}
	public int getId() {
		return id;
	}
	public int getsaleId() {
		return saleId;
	}
	
	// 4. interaction with the repository (a relational database in this simple example)
	/**
	 * The insert product in a sale SQL statement
	 */
	private static final String INSERT_PRODUCT_SALE_SQL = 
			"insert into saleproduct (id, qty, product_id, sale_id) "+
			"values (DEFAULT, ?, ?, ?)";

	/**
	 * Inserts the record in the products sale 
	 */
	public void insert() throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepareGetGenKey(INSERT_PRODUCT_SALE_SQL)) {
			// set statement arguments
			statement.setDouble(1, qty);
			statement.setInt(2, productId);
			statement.setInt(3, saleId);
			// executes SQL
			statement.executeUpdate();
			// Gets customer Id generated automatically by the database engine
			try (ResultSet rs = statement.getGeneratedKeys()) {
				rs.next(); 
				id = rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new PersistenceException ("Internal error!", e);
		}
	}
	
	/**
	 * The select the products of a sale by sale Id SQL statement
	 */
	private static final String GET_SALE_PRODUCTS_SQL = 
			"select * from saleproduct where sale_id = ?";		
	
	/**
	 * Gets the products of a sale by its sale id 
	 * 
	 * @param saleId The sale id to get the products of
	 * @return The set of products that compose the sale
	 * @throws PersistenceException When there is an error obtaining the
	 *         information from the database.
	 */
	public static Set<SaleProductRowDataGateway> getSaleProducts (int saleId) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_SALE_PRODUCTS_SQL)) {			
			// set statement arguments
			statement.setInt(1, saleId);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				// creates a new customer from the data retrieved from the database
				return loadProducts(rs);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a sale by its id", e);
		} 	
	}
	private static Set<SaleProductRowDataGateway> loadProducts(ResultSet rs) throws RecordNotFoundException {
		try {
			Set<SaleProductRowDataGateway> produtos = new HashSet<SaleProductRowDataGateway>();
			while (rs.next()){
				SaleProductRowDataGateway prod = new SaleProductRowDataGateway(rs.getInt("sale_id"), rs.getInt("product_id"), rs.getDouble("qty"));
				produtos.add(prod);
			}
			return produtos;
		} catch (SQLException e) {
			throw new RecordNotFoundException ("Sale does not exist", e);
		}
	}
	
	private static final String DEL_PROD_SQL = "delete from saleproduct where sale_id = ?";

	public void delete_prod() throws PersistenceException {		
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(DEL_PROD_SQL)) {
			// set statement arguments
			statement.setInt(1, id);
			// executes SQL
			statement.executeUpdate();
			// Gets customer Id generated automatically by the database engine
		} catch (SQLException e) {
			throw new PersistenceException ("Internal error!", e);
		}
	}
}
