package dataaccess;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import business.SaleStatus;

/**
 * An in-memory representation of a customer table record. 
 *	
 * Notes:
 * 1. See the notes for the CustomerRowGateway class
 * 
 * 2. Java makes available two Date classes (in fact, more in Java 8, 
 * but we will address it later (with JPA)): one in the package 
 * java.util, which is the one we normally use, and another in
 * java.sql, which is a subclass of java.util.date and that 
 * transforms the milliseconds representation according to the
 * "Date type of databases". For more information refer to 
 * http://download.oracle.com/javase/6/docs/api/java/sql/Date.html.
 * 
 * 3. When creating a new sale, we only pass the date and customer id 
 * parameters to the constructor. Moreover, attribute open is always 
 * set to 'O'. The remaining attributes are either set automatically (id) 
 * or when closing the sale (totalSale and totalDiscount). Also, the open 
 * attribute is set to 'C' upon payment. 
 * 
 * @author fmartins
 * @Version 1.2 (13/02/2015)
 *
 */
public class SaleRowDataGateway {

	// Sale attributes 
	private int customerId;
	private Date date;
	private int id;
	private String status;
	private double discount;
	private double total;
	
	//Constants for conversion of status
	private static final String OPEN = "O";
	private static final String CLOSED = "C";
	// 1. constructor 

	/**
	 * Creates a new sale given the client Id and the date it occurs.
	 * 
	 * @param customerId The customer Id the sale belongs to
	 * @param date The date the sale took place
	 */
	public SaleRowDataGateway(int customerId, Date date) {
		this.customerId = customerId;
		this.date = date;
	}

	// 2. getters and setters

	public int getId() {
		return id;
	}

	public SaleStatus getStatus() {
		if(status.equals(OPEN)) {
			return SaleStatus.OPEN;
		} 
		else{
			if(status.equals(CLOSED)) {
				return SaleStatus.CLOSED;
			}
			else{
				return SaleStatus.ANNUL;
			}
		}
	}

	public int getClientId() {
		return customerId;
	}

	public double getDiscount() {
		return discount;
	}
	
	public double getTotal() {
		return total;
	}
	public Date getDate() {
		return date;
	}

	// 3. interaction with the repository (a memory map in this simple example)
	/**
	 * The insert sale SQL statement
	 */
	private static final String INSERT_SALE_SQL = 
			"insert into sale (id, date, total, discount_total, status, customer_id) " + 
			"values (DEFAULT, ?, 0, 0, 'O', ?)";

	/**
	 * Stores the information in the repository
	 */
	public void insert () throws PersistenceException {		
		try (PreparedStatement statement = DataSource.INSTANCE.prepareGetGenKey(INSERT_SALE_SQL)) {
			// set statement arguments
			statement.setDate(1, new java.sql.Date(date.getTime()));
			statement.setInt(2, customerId);
			// executes SQL
			statement.executeUpdate();
			// Gets customer Id generated automatically by the database engine
			try (ResultSet rs = statement.getGeneratedKeys()) {
				rs.next();
				id = rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new PersistenceException ("Internal error!", e);
		}
	}

	/**
	 * The select a sale by Id SQL statement
	 */
	private static final String GET_SALE_BY_VAT_SQL = 
			"select * from sale where customer_id = ?";

	/**
	 * Gets a sale by its id 
	 * 
	 * @param id The sale id to search for
	 * @return The new object that represents an in-memory sale
	 * @throws PersistenceException In case there is an error accessing the database.
	 */
	public static SaleRowDataGateway getSaleByVAT (int customer_id) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_SALE_BY_VAT_SQL)) {			
			// set statement arguments
			statement.setInt(1, customer_id);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				// creates a new customer from the data retrieved from the database
				return loadSale(rs);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a sale by its id", e);
		} 	
	}
	
	/**
	 * The select a sale by Id SQL statement
	 */
	private static final String GET_SALE_SQL = 
			"select * from sale where id = ?";

	/**
	 * Gets a sale by its id 
	 * 
	 * @param id The sale id to search for
	 * @return The new object that represents an in-memory sale
	 * @throws PersistenceException In case there is an error accessing the database.
	 */
	public static SaleRowDataGateway getSaleById (int id) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_SALE_SQL)) {			
			// set statement arguments
			statement.setInt(1, id);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				// creates a new customer from the data retrieved from the database
				return loadSale(rs);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a sale by its id", e);
		} 	
	}
	private static SaleRowDataGateway loadSale(ResultSet rs) throws RecordNotFoundException {
		try {
			rs.next();
			SaleRowDataGateway newSale = new SaleRowDataGateway(rs.getInt("customer_id"), 
					rs.getDate("date"));
			newSale.id = rs.getInt("id");
			newSale.total = rs.getInt("total");
			newSale.discount = rs.getDouble("discount_total");
			newSale.status = rs.getString("status");

			return newSale;
		} catch (SQLException e) {
			throw new RecordNotFoundException ("Sale does not exist", e);
		}
	}
	
	private static final String UPDT_STATUS_ANNUL_SQL = "update sale set status='A' where id = ?";
	
	public void update () throws PersistenceException {		
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(UPDT_STATUS_ANNUL_SQL)) {
			// set statement arguments
			statement.setInt(1, id);
			// executes SQL
			statement.executeUpdate();
			// Gets customer Id generated automatically by the database engine
			/*try (ResultSet rs = statement.getGeneratedKeys()) {
				rs.next();
				id = rs.getInt(1);
			}*/
		} catch (SQLException e) {
			throw new PersistenceException ("Internal error!", e);
		}
	}
private static final String UPDT_TOTAL_DISCOUNT_SQL = "update sale set total=?, discount_total=? where id = ?";
	
	public void update_total_discount(double total, double discount) throws PersistenceException {		
		try (PreparedStatement statement = DataSource.INSTANCE.prepareGetGenKey(UPDT_TOTAL_DISCOUNT_SQL)) {
			// set statement arguments
			statement.setDouble(1, total);
			statement.setDouble(2, discount);
			statement.setInt(3, id);
			// executes SQL
			statement.executeUpdate();
			// Gets customer Id generated automatically by the database engine
			try (ResultSet rs = statement.getGeneratedKeys()) {
				rs.next();
				id = rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new PersistenceException ("Internal error!", e);
		}
	}
}
