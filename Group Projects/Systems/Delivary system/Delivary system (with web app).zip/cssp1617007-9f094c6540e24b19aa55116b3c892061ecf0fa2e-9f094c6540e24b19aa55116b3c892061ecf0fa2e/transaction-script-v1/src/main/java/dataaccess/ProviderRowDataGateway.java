package dataaccess;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProviderRowDataGateway {

	private String name;
	private int vatc;
	private int id;

	public ProviderRowDataGateway(int vatc, String name) {
		this.vatc = vatc;
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public int getProviderId(){
		return vatc;
	}
	public String getDesignation(){
		return name;
	}
	/**
	 * The insert customer SQL statement
	 */
	private static final String INSERT_CUSTOMER_SQL = 
			"insert into customer (id, vatnumber, designation) " +
			"values (DEFAULT, ?, ?)";
	public void insert () throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepareGetGenKey(INSERT_CUSTOMER_SQL)) {
			// set statement arguments
			statement.setInt(1, vatc);
			statement.setString(2, name);
			// executes SQL
			statement.executeUpdate();
			// Gets customer Id generated automatically by the database engine
			try (ResultSet rs = statement.getGeneratedKeys()) {
				rs.next(); 
				id = rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new PersistenceException ("Internal error!", e);
		}
	}
	private static final String GET_PROVIDER_BY_VATC_NUMBER_SQL = "select * from provider where vatc = ?";
	
	public static ProviderRowDataGateway getProviderByVATNumber (int vatc) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_PROVIDER_BY_VATC_NUMBER_SQL)) {			
			// set statement arguments
			statement.setInt(1, vatc);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				// creates a new customer from the data retrieved from the database
				return loadProvider(rs);
			}
		} catch (SQLException | PersistenceException e) {
			throw new PersistenceException("Internal error getting a provider by its vatc", e);
		}
	}
	
	/**
	 * The select customer by id SQL statement
	 */
	private static final String	GET_PROVIDER_BY_ID_SQL =
				"select * from provider where id = ?";

	/**
	 * Fetches a customer given its internal id number and returns a CustomerRowGateway 
	 * object with the data retrieved from the database. In case the customer
	 * is not found, a RecordNotFoundException is thrown.

	 * @param id The Id of the customer to fetch from the repository.
	 * @return The CustomerRowGateway corresponding to the customer with the id number.
	 * @throws RecordNotFoundException When the customer with the given id number is not found.
	 */
	public static ProviderRowDataGateway getProviderById (int id) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_PROVIDER_BY_ID_SQL)) {			
			// set statement arguments
			statement.setInt(1, id);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				// creates a new customer from the data retrieved from the database
				return loadProvider(rs);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a customer by its id", e);
		}
	}
	/**
	 * Creates a customer from a result set retrieved from the database.
	 * 
	 * @param rs The result set with the information to create the customer.
	 * @return A new customer loaded from the database.
	 * @throws RecordNotFoundException In case the result set is empty.
	 */
	private static ProviderRowDataGateway loadProvider(ResultSet rs) throws RecordNotFoundException {
		try {
			rs.next();
			ProviderRowDataGateway newProvider = new ProviderRowDataGateway(rs.getInt("vatc"), 
					rs.getString("designation"));
			newProvider.id = rs.getInt("id");
			return newProvider;
		} catch (SQLException e) {
			throw new RecordNotFoundException ("Provider does not exist", e);
		}
	}
}
