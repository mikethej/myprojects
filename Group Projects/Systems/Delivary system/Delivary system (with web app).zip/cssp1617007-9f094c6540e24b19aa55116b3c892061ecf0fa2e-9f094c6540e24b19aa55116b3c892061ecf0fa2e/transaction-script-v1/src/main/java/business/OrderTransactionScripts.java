package business;

import java.sql.Date;
import java.sql.SQLException;

import dataaccess.OrderRowDataGateway;
import dataaccess.PersistenceException;
import dataaccess.ProviderRowDataGateway;

public class OrderTransactionScripts {	
	public int newOrder(int vatc, int prodCode, double qty, String designation) throws ApplicationException, PersistenceException {
		ProviderRowDataGateway provider = new ProviderRowDataGateway(vatc, designation);
		OrderRowDataGateway newOrder = new OrderRowDataGateway(provider.getProviderId(), prodCode, qty);
		newOrder.insert(vatc, prodCode, qty, designation);
		return newOrder.getId();
	}
	public int recvOrder(int prodCode, int vatc, int qty_recv) throws PersistenceException, SQLException{
		ProviderRowDataGateway provider = ProviderRowDataGateway.getProviderByVATNumber(vatc);
		OrderRowDataGateway order = OrderRowDataGateway.getOrderByProdCode(prodCode);
		order.updateDateRecv();
		double qty_pend = order.getQuantityPend();
		if (qty_pend == 0.0){
			order.updateStatusRecv();
		}
		if(qty_recv<qty_pend){
			OrderRowDataGateway newOrder = new OrderRowDataGateway(provider.getProviderId(), prodCode, qty_pend);
			int id = order.getIdByProdCode(prodCode);
			Date date_antiga = (Date) order.getDatebyId(id);
			newOrder.insertPend(id, date_antiga, qty_pend);
			newOrder.updateStatusParcial(qty_recv);
			return newOrder.getId();
		}
		order.updateStatusRecv();
		return order.getId();
	}
}