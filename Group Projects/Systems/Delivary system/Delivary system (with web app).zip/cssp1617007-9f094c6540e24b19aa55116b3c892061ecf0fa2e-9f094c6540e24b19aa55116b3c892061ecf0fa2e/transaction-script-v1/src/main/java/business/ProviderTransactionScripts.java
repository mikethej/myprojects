package business;

import dataaccess.PersistenceException;
import dataaccess.ProviderRowDataGateway;
import dataaccess.RecordNotFoundException;

public class ProviderTransactionScripts {
public int addProvider (int vatc) throws ApplicationException {
		try {
			// gets the provider number having its vat number
			ProviderRowDataGateway provider = ProviderRowDataGateway.getProviderByVATNumber(vatc);
			// creates the sale
			ProviderRowDataGateway newSale = new ProviderRowDataGateway(provider.getProviderId(), provider.getDesignation());
			newSale.insert();
			return newSale.getId();
		} catch (RecordNotFoundException e) {
			throw new ApplicationException("There is no provider with the given VAT number " + vatc);
		} catch (PersistenceException e) {
			throw new ApplicationException("Internal error adding sale", e);
		}
	}
}
