package facade.dto;

import java.io.Serializable;

public class ProviderDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1426108145583202498L;

	public final int vatc;
	public final String designation;
	public final int id;

	public ProviderDTO(int vatc, String designation, int id) {
		this.vatc = vatc;
		this.designation = designation;
		this.id = id;
	}
}