package business;

import java.util.LinkedList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import facade.dto.ProviderDTO;
import facade.exceptions.ApplicationException;
import facade.handlers.IRemoveProviderHandlerRemote;

@Stateless
public class RemoveProviderHandler implements IRemoveProviderHandlerRemote {
	
	/**
	 * The customer's catalog
	 */
	@EJB
	private ProviderCatalog providerCatalog;

	@Override
	public ProviderDTO getProvider(int id) throws ApplicationException {
		Provider c = providerCatalog.getProviderById(id);
		return new ProviderDTO(c.getVATC(), c.getDesignation(), c.getId());
	}

	@Override
	public Iterable<ProviderDTO> getProviders() {
		List<ProviderDTO> providers = new LinkedList<>();
		for (Provider p : providerCatalog.getProviders())
			providers.add(new ProviderDTO(p.getVATC(), p.getDesignation(), p.getId()));
		return providers;
	}

	@Override
	public void deleteProvider(int id) throws ApplicationException {
		providerCatalog.deleteProvider(id);
	}	
}
