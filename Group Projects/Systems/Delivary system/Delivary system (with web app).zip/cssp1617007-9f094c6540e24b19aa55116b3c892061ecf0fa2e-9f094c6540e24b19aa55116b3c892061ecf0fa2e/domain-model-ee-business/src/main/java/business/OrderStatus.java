package business;

/**
 * 
 * The order status
 */
public enum OrderStatus {
	PENDENT, RECEIVE, PARCIAL;
}
