package business;

import java.util.LinkedList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.jws.WebService;

import facade.dto.ProviderDTO;
import facade.exceptions.ApplicationException;
import facade.handlers.IAddProviderHandlerRemote;

/**
 * Handles the add provider use case. This represents a very 
 * simplified use case with just one operation: addProvider.
 * 
 * @author fmartins
 * @version 1.1 (17/04/2015)
 *
 */
@Stateless
@WebService 
public class AddProviderHandler implements IAddProviderHandlerRemote {
	
	/**
	 * The provider's catalog
	 */
	@EJB
	private ProviderCatalog providerCatalog;
	
	/**
	 * The discount's catalog 
	 */
	@EJB
	private DiscountCatalog discountCatalog;
		
	/**
	 * Adds a new provider with a valid Number. It checks that there is no other 
	 * provider in the database with the same VAT.
	 * 
	 * @param vat The VAT of the provider
	 * @param denomination The provider's name
	 * @param phoneNumber The provider's phone 
	 * @param discountType The type of discount applicable to the provider
	 * @throws ApplicationException When the VAT number is invalid (we check it according 
	 * to the Portuguese legislation).
	 */
	@Override
	public ProviderDTO addProvider (int vat, String denomination) 
			throws ApplicationException {
		try {
			Provider c = providerCatalog.addProvider(vat, denomination);
			return new ProviderDTO(c.getVATC(), c.getDesignation(), c.getId());
		} catch (Exception e) {
			throw new ApplicationException ("Error adding provider with VAT " + vat, e);
		}
	}	
	
	public List<Discount> getDiscounts() throws ApplicationException {
		return new LinkedList<>(discountCatalog.getDiscounts());
	}
}
