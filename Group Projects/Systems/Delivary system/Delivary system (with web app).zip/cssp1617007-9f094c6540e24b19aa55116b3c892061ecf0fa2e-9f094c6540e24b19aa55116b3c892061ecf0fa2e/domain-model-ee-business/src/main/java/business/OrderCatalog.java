package business;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import facade.exceptions.ApplicationException;

/**
 * A catalog for orders
 */
@Stateless
public class OrderCatalog {

	/**
	 * Entity manager for accessing the persistence service 
	 */
	@PersistenceContext
	private EntityManager em;
	
	public Orders getOrder (int prodCod) throws ApplicationException {
		TypedQuery<Orders> query = em.createNamedQuery(Orders.FIND_BY_PROD_CODE, Orders.class);
		query.setParameter(Orders.PROD_CODE, prodCod);
		try {
			return query.getSingleResult();
		} catch (PersistenceException e) {
			throw new ApplicationException ("Order not found.");
		}
	}

	/**
	 * Creates a new order and adds it to the repository
	 * 
	 * @param provider
	 * The provider the orders belongs to
	 * @return The newly created order
	 */
	@Transactional(Transactional.TxType.REQUIRES_NEW)
	public Orders newOrder(int vat, int prodCode, double qty) throws ApplicationException {
		Orders order = new Orders(new Date(), vat, prodCode, qty, qty, OrderStatus.PENDENT, 0);
		em.persist(order);
		return order;
	}

	public Orders closeOrder(Orders order) throws ApplicationException {
		order = em.merge(order);
		order.receiveOrder();
		em.persist(order);
		return order;
	}
	@Transactional(Transactional.TxType.REQUIRES_NEW)
	public Orders recvOrder(int prodCode, int vatc, double qty_recv) throws SQLException, ApplicationException{
		Orders order = getOrder(prodCode);
		double qty_pend = order.getQty_pend();
		if(qty_pend == 0.0){
			order.setStatus(OrderStatus.RECEIVE);
		}
		if(qty_recv < qty_pend){
			Orders newOrder = newOrder(vatc, prodCode, qty_pend);
			int id = order.getId();
			Date date_antiga = (Date) order.getDate();
			newOrder.setId_orig(id);
			newOrder.setDate(date_antiga);
			newOrder.setQty_pend(qty_pend-qty_recv);
			newOrder.setStatus(OrderStatus.PARCIAL);
			em.persist(newOrder);
			return newOrder;
		}
		order.setStatus(OrderStatus.RECEIVE);
		em.persist(order);
		return order;
	}
	
	public List<Orders> getOrderPend (int prodCod) throws ApplicationException {
		TypedQuery<Orders> query = em.createNamedQuery(Orders.FIND_PEND_BY_PROD_CODE, Orders.class);
		query.setParameter(Orders.PROD_CODE, prodCod);
		query.setParameter(Orders.ORDER_STATUS, OrderStatus.PENDENT);
		try {
			return query.getResultList();
		} catch (PersistenceException e) {
			throw new ApplicationException ("Order not found.");
		}
	}
	
	public List<Orders> pendingOrders(int prodCode) throws ApplicationException{
		return getOrderPend(prodCode);
	}
}