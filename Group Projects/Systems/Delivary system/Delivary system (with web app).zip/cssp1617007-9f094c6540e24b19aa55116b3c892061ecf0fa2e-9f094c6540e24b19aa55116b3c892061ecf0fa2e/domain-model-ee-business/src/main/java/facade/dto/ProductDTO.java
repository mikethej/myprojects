package facade.dto;

import java.io.Serializable;

import business.Unit;

public class ProductDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4406491273575131179L;

	private int id;
	private int prodCod;
	private String description;
	private double faceValue;
	private double qty;
	private boolean discountEligibility;
	private Unit unit;
	
	public ProductDTO(int prodCod, String description, double faceValue, double qty, boolean discountEligibility, Unit unit2, int id) {
		this.setProdCod(prodCod);
		this.setDescription(description);
		this.setFaceValue(faceValue);
		this.setQty(qty);
		this.setDiscountEligibility(discountEligibility);
		this.setUnit(unit2);
		this.setId(id);
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getProdCod() {
		return prodCod;
	}

	public void setProdCod(int prodCod) {
		this.prodCod = prodCod;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getFaceValue() {
		return faceValue;
	}

	public void setFaceValue(double faceValue) {
		this.faceValue = faceValue;
	}

	public double getQty() {
		return qty;
	}

	public void setQty(double qty) {
		this.qty = qty;
	}

	public boolean isDiscountEligibility() {
		return discountEligibility;
	}

	public void setDiscountEligibility(boolean discountEligibility) {
		this.discountEligibility = discountEligibility;
	}

	public Unit getUnit() {
		return unit;
	}

	public void setUnit(Unit unit) {
		this.unit = unit;
	}
}