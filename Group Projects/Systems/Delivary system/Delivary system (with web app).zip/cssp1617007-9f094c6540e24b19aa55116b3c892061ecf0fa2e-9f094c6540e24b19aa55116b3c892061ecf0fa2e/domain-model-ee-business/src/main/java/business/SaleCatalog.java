package business;

import java.util.Date;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import facade.exceptions.ApplicationException;

/**
 * A catalog for sales
 */

@Stateless
public class SaleCatalog {

	/**
	 * Entity manager factory for accessing the persistence service
	 */
	@PersistenceContext
	private EntityManager em;

	/**
	 * Creates a new sale and adds it to the repository
	 * 
	 * @param customer
	 * The customer the sales belongs to
	 * @return The newly created sale
	 */
	public Sale newSale(Customer customer) throws ApplicationException {
		Sale sale = new Sale(new Date(), customer);
		em.persist(sale);
		return sale;
	}

	/**
	 * @param sale
	 * @param product
	 * @param qty
	 * @throws ApplicationException
	 */
	public Sale addProductToSale(Sale sale, Product product, double qty) throws ApplicationException {
		sale = em.merge(sale);
		sale.addProductToSale(product, qty);
		em.merge(product);
		em.persist(sale);
		return sale;
	}

	public Sale closeSale(Sale sale) throws ApplicationException {
		sale = em.merge(sale);
		sale.closeSale();
		em.persist(sale);
		return sale;
	}
	
	public Sale getSaleByID (int id) throws ApplicationException {
		TypedQuery<Sale> query = em.createNamedQuery(Sale.FIND_BY_ID, Sale.class);
		query.setParameter(Sale.ID, id);
		try {
			return query.getSingleResult();
		} catch (PersistenceException e) {
			throw new ApplicationException ("Customer not found.");
		}
	}
}