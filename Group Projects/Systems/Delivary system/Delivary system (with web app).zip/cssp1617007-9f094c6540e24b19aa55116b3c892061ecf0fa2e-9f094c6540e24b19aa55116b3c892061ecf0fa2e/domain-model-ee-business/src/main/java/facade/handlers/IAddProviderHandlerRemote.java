package facade.handlers;

import javax.ejb.Remote;

import facade.dto.ProviderDTO;
import facade.exceptions.ApplicationException;

@Remote
public interface IAddProviderHandlerRemote {

	public ProviderDTO addProvider (int vat, String denomination) 
			throws ApplicationException;
}
