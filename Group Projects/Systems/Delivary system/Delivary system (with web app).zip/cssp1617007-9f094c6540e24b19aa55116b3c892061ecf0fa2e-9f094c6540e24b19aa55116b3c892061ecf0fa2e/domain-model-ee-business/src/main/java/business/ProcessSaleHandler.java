package business;

import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;

import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.persistence.PersistenceException;

import business.Customer;
import business.CustomerCatalog;
import business.Product;
import business.Sale;
import business.SaleCatalog;
import facade.dto.ProductDTO;
import facade.exceptions.ApplicationException;
import facade.handlers.ProcessSaleHandlerRemote;

@Singleton
@WebService
public class ProcessSaleHandler implements ProcessSaleHandlerRemote{

	/**
	 * The sale's catalog
	 */
	@EJB
	private SaleCatalog saleCatalog;

	/**
	 * The customer's catalog
	 */
	@EJB
	private CustomerCatalog customerCatalog;

	/**
	 * The product's catalog
	 */
	@EJB
	private ProductCatalog productCatalog;

	/**
	 * The current sale
	 */
	private Sale currentSale;

	public ProcessSaleHandler() {
	}

	/**
	 * Creates a handler for the process sale use case given the sale, customer,
	 * and product catalogs.
	 * 
	 * @param saleCatalog
	 *            A sale's catalog
	 * @param customerCatalog
	 *            A customer's catalog
	 * @param productCatalog
	 *            A product's catalog
	 */
	public ProcessSaleHandler(SaleCatalog saleCatalog, CustomerCatalog customerCatalog, ProductCatalog productCatalog) {
		this.saleCatalog = saleCatalog;
		this.customerCatalog = customerCatalog;
		this.productCatalog = productCatalog;
	}

	/**
	 * Creates a new sale
	 * 
	 * @param vatNumber
	 *            The customer's VAT number for the sale
	 * @throws ApplicationException
	 *             In case the customer is not in the repository
	 */
	@WebMethod(operationName = "newSale")
	public void newSale(int vatNumber) throws ApplicationException {
		try {
			Customer c = customerCatalog.getCustomer(vatNumber);
			currentSale = saleCatalog.newSale(c);
		} catch (PersistenceException e) {
			throw new ApplicationException("Customer does not exist", e);
		}
	}

	/**
	 * Adds a product to the current sale
	 * 
	 * @param prodCod
	 *            The product code to be added to the sale
	 * @param qty
	 *            The quantity of the product sold
	 * @throws ApplicationException
	 *             When the sale is closed, the product code is not part of the
	 *             product's catalog, or when there is not enough stock to
	 *             proceed with the sale
	 */
	@WebMethod(operationName = "addProductToSale")
	public void addProductToSale(int prodCod, double qty) throws ApplicationException {
		try {
			Product p = productCatalog.getProduct(prodCod);
			currentSale = saleCatalog.addProductToSale(currentSale, p, qty);
		} catch (PersistenceException e) {
			throw new ApplicationException("Some error occured", e);
		}
	}
	
	@WebMethod(operationName = "annulSale")
	public void annulSale(int id) throws ApplicationException {
		try {
			Sale s = saleCatalog.getSaleByID(id);
			if (s.getStatus() != SaleStatus.ANNUL){
				List<String> produtos = s.getSaleProducts();
				for(String i : produtos){
					String[] t = i.split(Pattern.quote(" - "));
					double qty = Double.parseDouble(t[1]);
					Product produto = new Product();
					produto.setQty(produto.getQty()+qty);
				}
				s.setStatus(SaleStatus.ANNUL);
			}
		} catch (PersistenceException e) {
			throw new ApplicationException("Sale does not exist", e);
		}
	}

	@WebMethod(operationName = "closeSale")
	public void closeSale() throws ApplicationException {
		try {
			currentSale = saleCatalog.closeSale(currentSale);
		} catch (PersistenceException e) {
			throw new ApplicationException("Some error occured", e);
		}
	}

	@WebMethod(operationName = "getAllProducts")
	public List<ProductDTO> getAllProducts() throws ApplicationException {
		List<Product> productI = productCatalog.getAllProducts();
		List<ProductDTO> productDTO = new LinkedList<ProductDTO>();
		for (Product p : productI) {
			ProductDTO product = new ProductDTO(p.getProdCod(), p.getDescription(), 
					p.getFaceValue(), p.getQty(), p.isEligibleForDiscount(), p.getUnit(), p.getId());
			productDTO.add(product);
		}
		return productDTO;
	}

	/**
	 * @return The sale's discount, according to the customer discount type
	 * @throws ApplicationException
	 *             When some persistence error occurs
	 */
	public double getSaleDiscount() throws ApplicationException {
		return currentSale.discount();
	}

	/**
	 * @return The sale's total, before discount.
	 * @throws ApplicationException
	 *             When some persistence error occurs
	 */
	public double getSaleTotal() {
		return currentSale.total();
	}

	public Sale getCurrentSale() {
		return currentSale;
	}
}
