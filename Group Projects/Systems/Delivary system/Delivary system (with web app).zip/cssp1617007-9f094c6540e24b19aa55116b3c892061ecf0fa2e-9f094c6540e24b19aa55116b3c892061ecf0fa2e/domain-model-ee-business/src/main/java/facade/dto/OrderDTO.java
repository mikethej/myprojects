package facade.dto;

import java.io.Serializable;
import java.util.Date;

import business.OrderStatus;

public class OrderDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5184155857267458861L;

	private int id;
	private Date date;
	private int providerVat;
	private double qty_pend;
	private double qty_order;
	private int id_orig;
	private OrderStatus status;
	private int prodCode;
	
	public OrderDTO(Date date, int providerVat, int prodCode, double qty_order, int id){
		this.setId(id);
		this.setDate(date);
		this.setId_orig(id_orig);
		this.setProdCode(prodCode);
		this.providerVat = providerVat;
		this.setQty_order(qty_order);
		this.setQty_pend(qty_order);
		this.setStatus(status);
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getProviderVat() {
		return providerVat;
	}
	public double getQty_pend() {
		return qty_pend;
	}
	public void setQty_pend(double qty_pend) {
		this.qty_pend = qty_pend;
	}
	public double getQty_order() {
		return qty_order;
	}
	public void setQty_order(double qty_order) {
		this.qty_order = qty_order;
	}
	public int getId_orig() {
		return id_orig;
	}
	public void setId_orig(int id_orig) {
		this.id_orig = id_orig;
	}
	public OrderStatus getStatus() {
		return status;
	}
	public void setStatus(OrderStatus status) {
		this.status = status;
	}
	public int getProdCode() {
		return prodCode;
	}
	public void setProdCode(int prodCode) {
		this.prodCode = prodCode;
	}
}
