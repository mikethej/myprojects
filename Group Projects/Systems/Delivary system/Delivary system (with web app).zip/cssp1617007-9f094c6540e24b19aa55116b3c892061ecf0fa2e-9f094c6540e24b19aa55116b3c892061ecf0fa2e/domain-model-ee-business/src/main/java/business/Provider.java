package business;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@Entity  
@NamedQueries({
	@NamedQuery(name=Provider.FIND_PROV_BY_VAT_NUMBER, query="SELECT p FROM Provider p WHERE p.vatc = :" + 
			Provider.NUMBER_VATC),
	@NamedQuery(name=Provider.FIND_ALL_PROVIDERS, query="SELECT p FROM Provider p"),
})
public class Provider {

	// Named query name constants
	public static final String FIND_PROV_BY_VAT_NUMBER = "Provider.findByVATNumber";
	public static final String NUMBER_VATC = "vatc";
	public static final String FIND_ALL_PROVIDERS = "Provider.findAllProviders";

	// Customer attributes 

	/**
	 * Customer primary key. Needed by JPA. Notice that it is not part of the
	 * original domain model.
	 */
	@Id @GeneratedValue private int id;

	/**
	 * Customer's VAT number
	 */
	@Column(nullable = false, unique = true) private int vatc;

	/**
	 * Customer's name. In case of a company, the represents its commercial denomination 
	 */
	@Column(nullable = false) private String designation;

	/**
	 * Constructor needed by JPA.
	 */
	Provider() {
	}
	/**
	 * Creates a new provider given its VATC number and its designation.
	 * 
	 * @param vatNumber The provider's VAT number
	 * @param designation The provider's designation
	 * @pre isValidVAT(vat) 
	 */
	public Provider(int vatc, String designation) {
		this.vatc = vatc;
		this.designation = designation;
	}

	// 2. getters and setters

	public int getVATC() {
		return vatc;
	}

	public String getDesignation() {
		return designation;
	}
	/**
	 * Checks if a VAT number is valid.
	 * 
	 * @param vat The number to be checked.
	 * @return Whether the VAT number is valid. 
	 */
	public boolean isValidVAT(int vatc) {
		// If the number of digits is not 9, error!
		if (vatc < 100000000 || vatc > 999999999)
			return false;
		
		// If the first number is not 1, 2, 5, 6, 8, 9, error!
		int firstDigit = vatc / 100000000;
		if (firstDigit != 1 && firstDigit != 2 && 
			firstDigit != 5 && firstDigit != 6 &&
			firstDigit != 8 && firstDigit != 9)
			return false;
		
		// Checks the congruence modules 11.
		int sum = 0;
		int checkDigit = vatc % 10;
		vatc /= 10;
		
		for (int i = 2; i < 10 && vatc != 0; i++) {
			sum += vatc % 10 * i;
			vatc /= 10;
		}
		
		int checkDigitCalc = 11 - sum % 11;
		if (checkDigitCalc == 10)
			checkDigitCalc = 0;
		return checkDigit == checkDigitCalc;
	}

	public int getId() {
		return id;
	}
}