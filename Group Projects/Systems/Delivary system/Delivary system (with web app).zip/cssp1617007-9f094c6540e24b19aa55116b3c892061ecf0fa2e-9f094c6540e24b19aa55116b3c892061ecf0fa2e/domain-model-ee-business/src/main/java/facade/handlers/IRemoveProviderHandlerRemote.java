package facade.handlers;

import javax.ejb.Remote;

import facade.dto.ProviderDTO;
import facade.exceptions.ApplicationException;

@Remote
public interface IRemoveProviderHandlerRemote {

	public ProviderDTO getProvider(int id) throws ApplicationException;

	public Iterable<ProviderDTO> getProviders();

	public void deleteProvider(int id) throws ApplicationException;
}
