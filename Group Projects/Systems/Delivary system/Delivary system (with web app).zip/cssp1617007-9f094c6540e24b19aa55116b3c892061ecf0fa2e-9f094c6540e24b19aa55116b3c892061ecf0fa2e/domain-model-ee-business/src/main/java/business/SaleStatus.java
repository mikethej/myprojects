package business;

/**
 * The sale status
 * 
 * @author fmartins
 * @version 1.1 (4/10/2014)
 * 
 */
public enum SaleStatus {
	OPEN, CLOSED, ANNUL;
}
