package facade.interfaces;

import java.io.Serializable;

public interface IDiscount extends Serializable {

	String getDescription();

	int getId();

}