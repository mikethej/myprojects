package business;

import static javax.persistence.EnumType.STRING;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import facade.exceptions.ApplicationException;

/**
 * A order
 */
@Entity  
@NamedQueries({
@NamedQuery(name=Orders.FIND_BY_PROD_CODE, query="SELECT o FROM Orders o WHERE o.prodCode = :" + 
		Orders.PROD_CODE),
@NamedQuery(name=Orders.FIND_ALL_ORDERS, query="SELECT o FROM Orders o"),
@NamedQuery(name=Orders.FIND_PEND_BY_PROD_CODE, query="SELECT o FROM Orders o WHERE o.prodCode = :" + 
		Orders.PROD_CODE + " AND o.status = :" + Orders.ORDER_STATUS),
})
public class Orders {
	
	// Named query name constants
	public static final String FIND_BY_PROD_CODE = "Orders.findByProdCode";
	public static final String PROD_CODE = "prodCode";
	public static final String FIND_ALL_ORDERS = "Orders.findAllCustomers";
	public static final String FIND_PEND_BY_PROD_CODE = "Orders.findPendByProdCode";
	public static final String ORDER_STATUS = "status";
	
	/**
	 * Orders primary key. Needed by JPA. Notice that it is not part of the
	 * original domain model.
	 */
	@Id	@GeneratedValue private int id;
	
	/**
	 * The date the order was made 
	 */
	@Temporal(TemporalType.DATE) private Date date;
	
	@Column (nullable = false) private double qty_pend;
	@Column (nullable = false) private double qty_order;
	@Column (nullable = true) private int id_orig;
	/**
	 * Whether the order is open or closed. 
	 */
	@Enumerated(STRING) private OrderStatus status;
	
	@Column (nullable = false) private int vat;

	@Column (nullable = false) private int prodCode;
	
	/**
	 * Constructor needed by JPA.
	 */
	Orders () {
	}
	
	/**
	 * Creates a new sale given the date it occurred and the customer that
	 * made the purchase.
	 * 
	 * @param date The date that the sale occurred
	 * @param customer The customer that made the purchase
	 */
	public Orders(Date date, int vat, int prodCode, double qty, double qty_pend, OrderStatus status, int id_orig) {
		this.date = date;
		this.vat = vat;
		this.status = status;
		this.prodCode = prodCode;
		this.qty_order = qty;
		this.qty_pend = qty_pend;
		this.id_orig = id_orig;
	}
	
	public int getVat() {
		return vat;
	}
	
	public OrderStatus getStatus() {
		return status;
	}
	
	public boolean isPendent() {
		return status == OrderStatus.PENDENT;
	}
	
	public int getId() {
		return id;
	}
	
	public void receiveOrder() throws ApplicationException {
		if (isPendent()) {
			this.status = OrderStatus.RECEIVE;
		} else {
			throw new ApplicationException("Orders is already received");
		}
	}

	public int getProdCode() {
		return prodCode;
	}

	public double getQty_order() {
		return qty_order;
	}

	public void setQty_order(double qty_order) {
		this.qty_order = qty_order;
	}
	
	public void setStatus (OrderStatus status){
		this.status = status;
	}

	public double getQty_pend() {
		return qty_pend;
	}

	public void setQty_pend(double qty_pend) {
		this.qty_pend = qty_pend;
	}

	public int getId_orig() {
		return id_orig;
	}

	public void setId_orig(int id_orig) {
		this.id_orig = id_orig;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
}
