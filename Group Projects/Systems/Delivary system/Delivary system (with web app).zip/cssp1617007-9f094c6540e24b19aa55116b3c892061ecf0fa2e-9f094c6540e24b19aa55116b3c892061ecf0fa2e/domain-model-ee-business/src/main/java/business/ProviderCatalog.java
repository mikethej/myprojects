package business;

import java.util.LinkedList;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import facade.exceptions.ApplicationException;

/**
 * A catalog of providers
 */
@Stateless
public class ProviderCatalog {

	/**
	 * Entity manager for accessing the persistence service 
	 */
	@PersistenceContext
	private static EntityManager em;
	
	/**
	 * Finds a Provider given its VAT number.
	 * 
	 * @param vat The VAT number of the provider to fetch from the repository
	 * @return The Provider object corresponding to the provider with the vat number.
	 * @throws ApplicationException When the provider with the vat number is not found.
	 */
	public static Provider getProvider (int vat) throws ApplicationException {
		TypedQuery<Provider> query = em.createNamedQuery(Provider.FIND_PROV_BY_VAT_NUMBER, Provider.class);
		query.setParameter(Provider.NUMBER_VATC, vat);
		try {
			return query.getSingleResult();
		} catch (PersistenceException e) {
			throw new ApplicationException ("Provider not found.");
		}
	}
	
	/**
	 * Adds a new provider
	 * 
	 * @param vat The provider's VAT number
	 * @param designation The provider's designation
	 * @throws ApplicationException When the provider is already in the repository or the 
	 * vat number is invalid.
	 */
	@Transactional(Transactional.TxType.REQUIRES_NEW)
	public Provider addProvider (int vat, String designation) 
			throws ApplicationException {
		Provider provider = new Provider(vat, designation);
		em.persist(provider);
		return provider;
	}
	
	public Provider getProviderById(int id) throws ApplicationException {
		Provider p = em.find(Provider.class, id);
		if (p == null)
			throw new ApplicationException("Provider with id " + id + " not found");
		else
			return p;
	}
	
	public Iterable<Provider> getProviders() {
        TypedQuery<Provider> query = em.createNamedQuery(Provider.FIND_ALL_PROVIDERS, Provider.class);
        return new LinkedList<>(query.getResultList());
	}
	
	public void deleteProvider(int id) throws ApplicationException {
		Provider provider = em.find(Provider.class, id);
		if (provider == null)
			throw new ApplicationException("Provider with id " + id + " not found");
		em.remove(provider);
	}
}