package business;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.persistence.PersistenceException;

import facade.dto.OrderDTO;
import facade.exceptions.ApplicationException;
import facade.handlers.ProcessOrderHandlerRemote;

@Stateless
@WebService
public class ProcessOrderHandler implements ProcessOrderHandlerRemote {

	/**
	 * The order's catalog
	 */
	@EJB
	private OrderCatalog orderCatalog;

	/**
	 * The provider's catalog
	 */
	@EJB
	private ProviderCatalog providerCatalog;

	/**
	 * The product's catalog
	 */
	@EJB
	private ProductCatalog productCatalog;

	/**
	 * The current order
	 */
	
	private Orders currentOrder;

	/**
	 * Creates a new order
	 * 
	 * @param vatNumber
	 *            The provider's VAT number for the order
	 * @throws ApplicationException
	 *             In case the provider is not in the repository
	 */
	@WebMethod(operationName = "newOrder")
	public OrderDTO newOrder(int vatc, int prodCode, double qty) throws ApplicationException {
		try {
			currentOrder = orderCatalog.newOrder(vatc, prodCode, qty);
			return new OrderDTO(currentOrder.getDate(), vatc, currentOrder.getProdCode(), currentOrder.getQty_order(), currentOrder.getId());
		} catch (PersistenceException e) {
			throw new ApplicationException("Provider does not exist", e);
		}
	}

	@WebMethod(operationName = "closeOrder")
	public void closeOrder() throws ApplicationException {
		try {
			currentOrder = orderCatalog.closeOrder(currentOrder);
		} catch (PersistenceException e) {
			throw new ApplicationException("Some error occured", e);
		}
	}
	
	@WebMethod(operationName = "receiveOrder")
	public void recvOrder(int prodCode, int vatc, double qty_recv) throws ApplicationException, SQLException {
		try {
			currentOrder = orderCatalog.recvOrder(prodCode, vatc, qty_recv);
		} catch (PersistenceException e) {
			throw new ApplicationException("Some error occured", e);
		}
	}
	
	@WebMethod(operationName = "pendingOrders")
	public List<OrderDTO> pendingOrders(int prodCode) throws ApplicationException, SQLException {
		try {
			List<Orders> lista = orderCatalog.pendingOrders(prodCode);
			List<OrderDTO> lista2 = new ArrayList<OrderDTO>();
			for(Orders cenas : lista){
				OrderDTO nas = new OrderDTO(cenas.getDate(), cenas.getVat(), cenas.getProdCode(), cenas.getQty_order(), cenas.getId());
				lista2.add(nas);
			}
			return lista2;
		} catch (PersistenceException e) {
			throw new ApplicationException("Some error occured", e);
		}
	}
	
	public Orders getCurrentOrder() {
		return currentOrder;
	}
}
