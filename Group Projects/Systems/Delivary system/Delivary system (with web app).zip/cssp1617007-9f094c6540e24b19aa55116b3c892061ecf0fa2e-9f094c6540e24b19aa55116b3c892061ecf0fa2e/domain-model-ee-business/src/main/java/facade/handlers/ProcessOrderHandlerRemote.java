package facade.handlers;

import java.sql.SQLException;
import java.util.List;

import javax.ejb.Remote;

import business.Orders;
import facade.dto.OrderDTO;
import facade.exceptions.ApplicationException;

@Remote
public interface ProcessOrderHandlerRemote {

	public OrderDTO newOrder(int vatc, int prodCode, double qty) throws ApplicationException;
	
	public void closeOrder() throws ApplicationException;
	
	public void recvOrder(int prodCode, int vatc, double qty_recv) throws ApplicationException, SQLException;
	
	public List<OrderDTO> pendingOrders(int prodCode) throws ApplicationException, SQLException;
	
	public Orders getCurrentOrder();
}
