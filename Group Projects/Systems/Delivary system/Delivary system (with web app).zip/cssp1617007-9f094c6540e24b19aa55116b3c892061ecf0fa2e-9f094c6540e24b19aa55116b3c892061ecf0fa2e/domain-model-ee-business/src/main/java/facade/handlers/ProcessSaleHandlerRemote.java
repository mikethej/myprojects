package facade.handlers;

import java.util.List;

import javax.ejb.Remote;

import business.Sale;
import facade.dto.ProductDTO;
import facade.exceptions.ApplicationException;

@Remote
public interface ProcessSaleHandlerRemote {

	public void newSale(int vatNumber) throws ApplicationException;
	
	public void addProductToSale(int prodCod, double qty) throws ApplicationException;
	
	public void annulSale(int id) throws ApplicationException;
	
	public List<ProductDTO> getAllProducts() throws ApplicationException;
	
	public void closeSale() throws ApplicationException;
	
	public double getSaleDiscount() throws ApplicationException;
	
	public double getSaleTotal();
	
	public Sale getCurrentSale();
}
