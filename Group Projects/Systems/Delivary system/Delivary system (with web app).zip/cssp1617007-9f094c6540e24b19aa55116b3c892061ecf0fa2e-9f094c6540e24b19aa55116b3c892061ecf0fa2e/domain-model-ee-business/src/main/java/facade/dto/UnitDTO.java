package facade.dto;

import java.io.Serializable;

public class UnitDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5089585749744631641L;

	private int id;
	private String description;
	private String abbreviation;

	public UnitDTO(String description, String abbreviation, int id) {
		this.setDescription(description);
		this.setAbbreviation(abbreviation);
		this.setId(id);
	}

	public UnitDTO(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAbbreviation() {
		return abbreviation;
	}

	public void setAbbreviation(String abbreviation) {
		this.abbreviation = abbreviation;
	}

}