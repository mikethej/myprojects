package business;

import java.util.Date;
import dataaccess.OrderTableGateway;
import dataaccess.Persistence;
import dataaccess.PersistenceException;
import dataaccess.TableData;
import dataaccess.TableData.Row;

public class Order extends TableModule{
	
	private int orderId;
	private OrderTableGateway ordera;
	private OrderTableGateway orderb;
	/**
	 * Constructs a order module given the persistence repository
	 * 
	 * @param persistence The persistence repository
	 */
	public Order(Persistence persistence) {
		super(persistence);
	}
	
	/**
	 * Add a new order.
	 * Notice the interaction with the Provider module. We use the
	 * provider module to get the provider id of the provider with
	 * a given VAT number. 
	 * 
	 * @param vatc The VATC number of the provider the order belongs to
	 * @return The internal order id so that products may be added to the sale
	 * @throws ApplicationException When there is no provider with the given
	 * VATC number or when there is an unexpected error add the sale.
	 */
	public int newOrder (int vatc, int prodCode, double qty_order, String designacao) throws ApplicationException {
		try {
			return persistence.orderTableGateway.insert(vatc, prodCode, qty_order, designacao);
		} catch (PersistenceException e) {
			throw new ApplicationException("There was an internal error adding the order", e);
		}
	}
	public int recvOrder(int prodCode, int vatc, double qty_recv) throws PersistenceException{
		TableData order = persistence.orderTableGateway.findByProdCode(prodCode);
		Row rorder = order.iterator().next();
		orderId = persistence.orderTableGateway.readId(rorder);
		persistence.orderTableGateway.updateDateRecv(orderId);
		ordera = persistence.orderTableGateway;
		if(ordera.readQty_Pend(rorder) == 0){
			ordera.updateStatusRecv(orderId);
		}
		if(qty_recv < ordera.readQty_Pend(rorder)){
			Date date_antiga = ordera.readDate_order(rorder);
			Double qty = ordera.readQty_Pend(rorder);
			orderb = persistence.orderTableGateway;
			TableData cenas = persistence.orderTableGateway.findByProdCode(prodCode);
			TableData cenasaa = persistence.providerTableGateway.findWithVATNumber(vatc);
			Row cenasa = cenas.iterator().next();
			String designacao = cenasaa.iterator().next().getString("DESIGNATION");
			orderb.insertPend(vatc, prodCode, qty-qty_recv, orderId, date_antiga, designacao);
			return orderb.readId(cenasa);
		}
		return ordera.readId(rorder);
	}
}
