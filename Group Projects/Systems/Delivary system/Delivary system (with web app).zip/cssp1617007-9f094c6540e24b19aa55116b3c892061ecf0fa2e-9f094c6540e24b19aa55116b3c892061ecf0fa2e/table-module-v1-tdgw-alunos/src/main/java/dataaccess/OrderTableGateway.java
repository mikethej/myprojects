package dataaccess;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;

import business.OrderStatus;
import dataaccess.TableData.Row;

/**
 * Table Data Gateway for the sales's table
 */
public class OrderTableGateway extends TableDataGateway {
	
	/**
     * Table name
     */
	private static final String TABLE_NAME = "orderprod";
	
	/**
	 * Columns' labels
	 */
	private static final String ID = "ID";
	private static final String ID_O = "ID_O";
	private static final String DESIGNATION = "DESIGNATION";
	private static final String VATC = "VATC";
	private static final String PRODUCT_CODE = "PRODUCT_CODE";
	private static final String QTY_PEND = "QTY_PEND";
	private static final String QTY_ORDER = "QTY_ORDER";
	private static final String DATE_ORDER = "DATE_ORDER";
	private static final String DATE_RECV = "DATE_RECV";
	private static final String DATE_ESTIM = "DATE_ESTIM";
	private static final String STATUS = "STATUS";

	// SQL constants
	/**
	 * The insert sale SQL statement
	 */
	private static final String INSERT_ORDER_SQL = 
			"insert into " + TABLE_NAME + " (" + ID + ", " + ID_O + ", " + DESIGNATION + ", " +
			VATC + ", " + PRODUCT_CODE + ", " + QTY_PEND + ", " + QTY_ORDER + ", " + DATE_ORDER + 
			", " + DATE_RECV + ", " + DATE_ESTIM + ", " + STATUS + ")" +
			"values (DEFAULT, 0, ?, ?, ?, ?, ?, ?, NULL, ?, 'P')";
	
	/**
	 * The insert sale SQL statement
	 */
	private static final String INSERT_ORDER_PEND_SQL = 
			"insert into " + TABLE_NAME + " (" + ID + ", " + ID_O + ", " + DESIGNATION + ", " +
			VATC + ", " + PRODUCT_CODE + ", " + QTY_PEND + ", " + QTY_ORDER + ", " + DATE_ORDER + 
			", " + DATE_RECV + ", " + DATE_ESTIM + ", " + STATUS + ") " +
			"values (DEFAULT, ?, ?, ?, ?, ?, ?, ?, NULL, ?, 'L')";
	
	/**
	 * The select a sale by Id SQL statement
	 */
	private static final String GET_ORDER_SQL = 
			"select * from "+ TABLE_NAME + "where " + ID + " = ?";
	
	/**
	 * The select a sale by ProdCode SQL statement
	 */
	private static final String GET_ORDER_BY_PROD_CODE_SQL = 
			"select * from "+ TABLE_NAME + " where " + PRODUCT_CODE + " = ?";
	/**
	 * The select a sale by VATC SQL statement
	 */
	private static final String GET_ORDER_BY_VATC_SQL = 
			"select * from "+ TABLE_NAME + " where " + VATC + " = ?";
	
	
	private static final String	UPDATE_DATE_RECV_SQL = 
			"update " + TABLE_NAME + " set " + DATE_RECV + " =? where " + ID + " = ?";
	
	private static final String	UPDATE_STATUS_RECV_SQL = 
			"update " + TABLE_NAME + " set " + STATUS + "='R', " + QTY_PEND + " =0 where "+ ID +" = ?";
	
	private static final String GET_ORDER_BY_PROD_CODE_PARCIAL_SQL = 
			"select * from "+ TABLE_NAME +" where "+ ID +" = ? and (" + STATUS +"='P' or " + STATUS +"='L')";
	
	/**
	 * Strings used to register the status of a sale in the Sale table
	 */
	private static final String PENDENT = "P";
	private static final String RECEIVE = "R";
	
	private java.sql.Date date_recv = new java.sql.Date(Calendar.getInstance().getTimeInMillis() + (1000*60*60*24*7));
	private java.sql.Date date_order = new java.sql.Date(Calendar.getInstance().getTimeInMillis());
	OrderTableGateway(DataSource dataSource) {
		super(dataSource);
	}
	
	/**
	 * Add a new order to the database
	 * 
	 * @param providerId The provider id of the sale
	 * @return The order id just created
	 * @throws PersistenceException In case an internal database error occurs
	 */
	public int insert (int vatc, int prodCode, double qty_order, String designacao) throws PersistenceException {
		try (PreparedStatement statement = dataSource.prepareGetGenKey(INSERT_ORDER_SQL)) {
			// set statement arguments
			statement.setString(1, designacao);
			statement.setInt(2, vatc);
			statement.setInt(3, prodCode);
			statement.setDouble(4, qty_order);
			statement.setDouble(5, qty_order);
			statement.setDate(6, date_order);
			statement.setDate(7, date_recv);
			// executes SQL
			statement.executeUpdate();
			// Gets customer Id generated automatically by the database engine
			try(ResultSet rs = statement.getGeneratedKeys()){
				rs.next();
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error adding the customer", e);
		}
	}
	
	/**
	 * Add a new order to the database
	 * 
	 * @param providerId The provider id of the sale
	 * @return The order id just created
	 * @throws PersistenceException In case an internal database error occurs
	 */
	public int insertPend (int vatc, int prodCode, double qty_order, int og_id, Date date_ant, String designacao) throws PersistenceException {
		try (PreparedStatement statement = dataSource.prepareGetGenKey(INSERT_ORDER_PEND_SQL)) {
			// set statement arguments
			statement.setInt(1, og_id);
			statement.setString(2, designacao);
			statement.setInt(3, vatc);
			statement.setInt(4, prodCode);
			statement.setDouble(5, qty_order);
			statement.setDouble(6, qty_order);
			statement.setDate(7, new java.sql.Date(date_ant.getTime()));
			statement.setDate(8, date_recv);
			// executes SQL
			statement.executeUpdate();
			// Gets customer Id generated automatically by the database engine
			try(ResultSet rs = statement.getGeneratedKeys()){
				rs.next();
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error adding the customer", e);
		}
	}
	
	/**
	 * Gets a order by its id 
	 * 
	 * @param orderId The sale id to search for
	 * @return The result set with information about the sale
	 * @throws PersistenceException In case there is an error accessing the database.
	 */
	public TableData find (int orderId) throws PersistenceException {
		try (PreparedStatement statement = dataSource.prepare(GET_ORDER_SQL)) {			
			// set statement arguments
			statement.setInt(1, orderId);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				TableData td = new TableData();
				td.populate(rs);
				return td;
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a order by its id", e);
		}
	}
	
	/**
	 * Gets a order by its vatc
	 * 
	 * @param orderId The sale id to search for
	 * @return The result set with information about the sale
	 * @throws PersistenceException In case there is an error accessing the database.
	 */
	public TableData findByVATC (int vatc) throws PersistenceException {
		try (PreparedStatement statement = dataSource.prepare(GET_ORDER_BY_VATC_SQL)) {			
			// set statement arguments
			statement.setInt(1, vatc);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				TableData td = new TableData();
				td.populate(rs);
				return td;
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a order by its id", e);
		}
	}
	
	public void updateDateRecv(int id) throws PersistenceException {
		try (PreparedStatement statement = dataSource.prepare(UPDATE_DATE_RECV_SQL)){
			// set statement arguments
			statement.setDate(1, date_order);
			statement.setInt(2, id);
			// execute SQL
			statement.executeUpdate();
		} catch (SQLException e) {
			throw new PersistenceException("Internal error updating product " + id + " stock amount.", e);
		}
	}
	/**
	 * Updates the product status
	 * 
	 * @throws PersistenceException
	 */
	public void updateStatusRecv (int id) throws PersistenceException {
		try (PreparedStatement statement = dataSource.prepare(UPDATE_STATUS_RECV_SQL)){
			// set statement arguments
			statement.setInt(1, id);
			// execute SQL
			statement.executeUpdate();
		} catch (SQLException e) {
			throw new PersistenceException("Internal error updating product " + id + " stock amount.", e);
		}
	}
	/**
	 * Gets a order by its prodCode
	 * 
	 * @param orderId The sale id to search for
	 * @return The result set with information about the sale
	 * @throws PersistenceException In case there is an error accessing the database.
	 */
	public TableData findByProdCode (int prodCode) throws PersistenceException {
		try (PreparedStatement statement = dataSource.prepare(GET_ORDER_BY_PROD_CODE_SQL)) {			
			// set statement arguments
			statement.setInt(1, prodCode);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				TableData td = new TableData();
				td.populate(rs);
				return td;
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a order by its id", e);
		}
	}
	
	public TableData getOrderByIdParcial(int id) throws PersistenceException {
		try (PreparedStatement statement = dataSource.prepare(GET_ORDER_BY_PROD_CODE_PARCIAL_SQL)) {			
			// set statement arguments
			statement.setInt(1, id);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				TableData td = new TableData();
				td.populate(rs);
				return td;
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a customer by its VAT number", e);
		} 
	}
	
	/**
	 * Reads from a result set the value of the corresponding column
	 * @param rs 
	 * @return the conversion of the value read from the result set 
	 * @throws PersistenceException When there is an error in the reading or conversion
	 */
	public int readId(Row rs) throws PersistenceException{
		return rs.getInt(ID);
	}
	/**
	 * Reads from a result set the value of the corresponding column
	 * @param rs 
	 * @return the conversion of the value read from the result set 
	 * @throws PersistenceException When there is an error in the reading or conversion
	 */
	public int readOrigId(Row rs) throws PersistenceException{
		return rs.getInt(ID_O);
	}
	/**
	 * Reads from a result set the value of the corresponding column
	 * @param rs 
	 * @return the conversion of the value read from the result set 
	 * @throws PersistenceException When there is an error in the reading or conversion
	 */
	public String readDesignation(Row rs) throws PersistenceException{
		return rs.getString(DESIGNATION);
	}
	/**
	 * Reads from a result set the value of the corresponding column
	 * @param rs 
	 * @return the conversion of the value read from the result set 
	 * @throws PersistenceException When there is an error in the reading or conversion
	 */
	public int readVATC(Row rs) throws PersistenceException{
		return rs.getInt(VATC);
	}
	/**
	 * Reads from a result set the value of the corresponding column
	 * @param rs 
	 * @return the conversion of the value read from the result set 
	 * @throws PersistenceException When there is an error in the reading or conversion
	 */
	public int readProduct_code(Row rs) throws PersistenceException{
		return rs.getInt(PRODUCT_CODE);
	}
	/**
	 * Reads from a result set the value of the corresponding column
	 * @param rs 
	 * @return the conversion of the value read from the result set 
	 * @throws PersistenceException When there is an error in the reading or conversion
	 */
	public Double readQty_Pend(Row rs) throws PersistenceException{
		return rs.getDouble(QTY_PEND);
	}
	/**
	 * Reads from a result set the value of the corresponding column
	 * @param rs 
	 * @return the conversion of the value read from the result set 
	 * @throws PersistenceException When there is an error in the reading or conversion
	 */
	public Double readQty_Ord(Row rs) throws PersistenceException{
		return rs.getDouble(QTY_ORDER);
	}
	/**
	 * Reads from a result set the value of the corresponding column
	 * @param rs 
	 * @return the conversion of the value read from the result set 
	 * @throws PersistenceException When there is an error in the reading or conversion
	 */
	public Date readDate_order(Row rs) throws PersistenceException{
		return rs.getDate(DATE_ORDER);
	}
	/**
	 * Reads from a result set the value of the corresponding column
	 * @param rs 
	 * @return the conversion of the value read from the result set 
	 * @throws PersistenceException When there is an error in the reading or conversion
	 */
	public Date readDate_recv(Row rs) throws PersistenceException{
		return rs.getDate(DATE_RECV);
	}
	/**
	 * Reads from a result set the value of the corresponding column
	 * @param rs 
	 * @return the conversion of the value read from the result set 
	 * @throws PersistenceException When there is an error in the reading or conversion
	 */
	public Date readDate_estim(Row rs) throws PersistenceException{
		return rs.getDate(DATE_ESTIM);
	}
	public OrderStatus readStatus(Row rs) throws PersistenceException{
		String status;
		try {
			status = rs.getString(STATUS);
			if(status.equals(PENDENT)) {
				return OrderStatus.PENDENT;
			} 
			else {
				if(status.equals(RECEIVE)) {
					return OrderStatus.RECEIVE;
				}
				else{
					return OrderStatus.PARCIAL;
				}
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			throw new PersistenceException("Internal error converting Sale Status", e);
		}
	}
}
