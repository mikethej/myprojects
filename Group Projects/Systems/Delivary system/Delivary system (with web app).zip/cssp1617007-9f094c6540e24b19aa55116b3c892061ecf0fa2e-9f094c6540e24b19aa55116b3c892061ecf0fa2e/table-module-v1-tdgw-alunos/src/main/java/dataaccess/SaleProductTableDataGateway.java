package dataaccess;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dataaccess.TableData.Row;

/**
 * Table Data Gateway for the salesproduct's table
 * 
 *   
 * @author fmartins
 * @version 1.1 (5/10/2015)
 *
 */
public class SaleProductTableDataGateway extends TableDataGateway {

    /**
     * Table name
     */
	private static final String TABLE_NAME = "saleproduct";

	/**
	 * Columns' labels
	 */	
	private static final String ID = "ID";
	private static final String QTY= "QTY";
	private static final String PRODUCT_ID = "PRODUCT_ID";
	private static final String SALE_ID = "SALE_ID";

	// SQL constants

	private static final String INSERT_PRODUCT_SALE_SQL = 
			"insert into " + TABLE_NAME + " (" + ID + ", " + QTY + ", " + PRODUCT_ID + ", " + SALE_ID + ") " +
			"values (DEFAULT, ?, ?, ?)";
	/**
	 * The select the products of a sale by sale Id SQL statement
	 */
	private static final String GET_SALE_PRODUCTS_SQL = 
			"select * from "+ TABLE_NAME + "where" + ID + " = ?";
	
	SaleProductTableDataGateway(DataSource dataSource) {
		super(dataSource);
	}


	/**
	 * Inserts the record in the products sale 
	 * 
	 * @param saleId The id of the sale to add the product to
	 * @param productId The id of the product to add to the sale
	 * @param qty The amount of the product to be sold
	 * @throws PersistenceException When an internal error adding a product to a sale occurs
	 */
	public void addProductToSale (int saleId, int productId, double qty) throws PersistenceException {
		try (PreparedStatement statement = dataSource.prepare(INSERT_PRODUCT_SALE_SQL)) {
			// set statement arguments
			statement.setDouble(1, qty);
			statement.setInt(2, productId);
			statement.setInt(3, saleId);
			// execute SQL
			statement.executeUpdate();
		} catch (SQLException e) {
			throw new PersistenceException("Internal error adding the customer", e);
		}
	}

	/**
	 * Gets the products of a sale by its sale id 
	 * 
	 * @param saleId The sale id to get the products of
	 * @return The set of products that compose the sale
	 * @throws PersistenceException When there is an error obtaining the
	 *         information from the database.
	 */
	public TableData getSaleProducts (int saleId) throws PersistenceException {
		try (PreparedStatement statement = dataSource.prepare(GET_SALE_PRODUCTS_SQL)) {			
			// set statement arguments
			statement.setInt(1, saleId);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				TableData td = new TableData();
				td.populate(rs);
				return td;
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a sale by its id", e);
		}
	}

	/**
	 * Reads from a result set the value of the corresponding column
	 * @param rs 
	 * @return the conversion of the value read from the result set 
	 * @throws PersistenceException When there is an error in the reading or conversion
	 */
	public double readQuantity(Row rs) throws PersistenceException{
		return rs.getDouble(QTY);
	}

	/**
	 * Reads from a result set the value of the corresponding column
	 * @param rs 
	 * @return the conversion of the value read from the result set 
	 * @throws PersistenceException When there is an error in the reading or conversion
	 */
	public int readSaleId(Row rs) throws PersistenceException{
		return rs.getInt(SALE_ID);
	}

	/**
	 * Reads from a result set the value of the corresponding column
	 * @param rs 
	 * @return the conversion of the value read from the result set 
	 * @throws PersistenceException When there is an error in the reading or conversion
	 */
	public int readProductId(Row rs) throws PersistenceException{
		return rs.getInt(PRODUCT_ID);
	}


}
