package business;

import dataaccess.Persistence;

public abstract class TableModule {

	protected Persistence persistence;
	
	public TableModule (Persistence persistence) {
		this.persistence = persistence;
	}

}
