package business;

import dataaccess.Persistence;
import dataaccess.PersistenceException;
import dataaccess.TableData;
import dataaccess.TableData.Row;

/**
 * The table module of a provider.
 */
public class Provider extends TableModule {
	/**
	 * Constructs a provider module given the persistence repository
	 * 
	 * @param persistence The persistence repository
	 */
	public Provider(Persistence persistence) {
		super(persistence);
	}

	
	/**
	 * @param vat The VAT number of the provider to get its internal id number
	 * @return The providerId of the provider with the vat number 
	 * @throws ApplicationException When the provider is not found or when some 
	 * obscure database internal error occurs (not in the this version of the 
	 * example)
	 */
	public int getProviderId (int vatc) throws ApplicationException {
		try {
			TableData td = persistence.providerTableGateway.findWithVATNumber(vatc);
			if (!td.isEmpty()) {
				Row firstRow = td.iterator().next();
				return persistence.providerTableGateway.readID(firstRow);
			} else 
				throw new ApplicationException("Provider with VAT number " + vatc + " does not exist.");
		} catch (PersistenceException e) {
			throw new ApplicationException ("Internal error obtaining provider with VAT number " + vatc, e);
		} 
	}
}
