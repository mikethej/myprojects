package dataaccess;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dataaccess.TableData.Row;

/**
 * Table Data Gateway for the provider's table
 */
public class ProviderTableGateway extends TableDataGateway{
	/**
	 * Table name
	 */
	private static final String TABLE_NAME = "provider";

	/**
     * Columns' labels
	 */	
	private static final String ID = "ID";
	private static final String DESIGNATION = "DESIGNATION";
	private static final String VATC = "VATC";

	// SQL constants
	
	/**
	 * The select customer by VAT SQL statement
	 */
	private static final String GET_PROVIDER_BY_VAT_NUMBER_SQL = 
			"select * from " + TABLE_NAME + " where " + VATC + " = ?";

	/**
	 * The select customer by id SQL statement
	 */
	private static final String GET_PROVIDER_BY_ID_SQL =
			"select * from " + TABLE_NAME + " where " + ID + " = ?";	
	
	/**
	 * The insert customer SQL statement
	 */
	private static final String INSERT_PROVIDER_SQL = 
			"insert into " + TABLE_NAME + " (" + ID + ", " + DESIGNATION + ", " + VATC + ") " +
			"values (DEFAULT, ?, ?)";
	
	ProviderTableGateway(DataSource dataSource) {
		super(dataSource);
	}
	/**
	 * Fetches a provider given its VATC and returns a result set with the
	 * result. Notice that it is fundamentally different from ProviderRowDataGateway
	 * that returns a ProviderRowDataGateway object, instead. 
	 * If there is some problem accessing the database a PersistenceException is 
	 * thrown. 
	 * 
	 * @param vatc The VATC of the provider to fetch from the database
	 * @return The ProviderRowGateway corresponding to the customer with the vat number.
	 * @throws PersistenceException In case a database error is thrown
	 */
	public TableData findWithVATNumber(int vatc) throws PersistenceException {
		try (PreparedStatement statement = dataSource.prepare(GET_PROVIDER_BY_VAT_NUMBER_SQL)) {
			// set statement arguments
			statement.setInt(1, vatc);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				TableData td = new TableData();
				td.populate(rs);
				return td;
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error obtaining the provider by VAT number", e);
		}
	}
	/**
	 * Gets a client by its Id number
	 * 
	 * @param id The id of the client to search for
	 * @return The result set of the query
	 * @throws PersistenceException When there is an internal error interaction with the database
	 */
	public TableData getProviderById(int id) throws PersistenceException {
		try (PreparedStatement statement = dataSource.prepare(GET_PROVIDER_BY_ID_SQL)) {			
			// set statement arguments
			statement.setInt(1, id);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				TableData td = new TableData();
				td.populate(rs);
				return td;
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error obtaining the  provider by id", e);
		}
	}
	/**
	 * Add a new client to the database provided that its VAT number 
	 * is not in the database
	 * 
	 * @param vat The VAT number of the customer
	 * @param designation The customer's name
	 * @param phoneNumber The customer's phone number
	 * @param discountType The discount type for the customer
	 * @throws PersistenceException When there is an error interacting with the database
	 */
	public void insert (int vatc, String designation) throws PersistenceException {
		try (PreparedStatement statement = dataSource.prepare(INSERT_PROVIDER_SQL)) {
			// set statement arguments
			statement.setString(1, designation);
			statement.setInt(2, vatc);
			// execute SQL
			statement.executeUpdate();
		} catch (SQLException e) {
			throw new PersistenceException("Internal error adding the provider", e);
		}
	}
	/**
	 * Reads from a result set the value of the corresponding column
     *
	 * @param r The row to get the information from
	 * @return the conversion of the value read from the result set 
	 * @throws PersistenceException When there is an error interacting with the database
	 */
	public int readID(Row r) throws PersistenceException{
		return r.getInt(ID);
	}

	/**
	 * Reads from a result set the value of the corresponding column
     *
     * @param r The row to get the information from
	 * @return the conversion of the value read from the result set 
	 * @throws PersistenceException When there is an error in the reading or conversion
	 */
	public int readVatNumber(Row r) throws PersistenceException{
		return r.getInt(VATC);
	}

	/**
	 * Reads from a result set the value of the corresponding column
     *
     * @param r The row to get the information from
	 * @return the conversion of the value read from the result set
	 * @throws PersistenceException  When there is an error in the reading or conversion
	 */
	public String readDesignation(Row r) throws PersistenceException {
		return r.getString(DESIGNATION);
	}
}
