package business;


import dataaccess.Persistence;
import dataaccess.PersistenceException;

/**
 * A table module for the products of a sale.
 * See remarks in the Customer class.
 * 
 * @author fmartins
 * @version 1.1 (6/11/2016)
 *
 */
public class SaleProduct extends TableModule {

	/**
	 * Constructs a saleproduct module given the persistence repository
	 * 
	 * @param persistence The persistence repository
	 */
	public SaleProduct (Persistence persistence) {
		super(persistence);
	}

	/**
	 * Add a product to sale.
	 * 
	 * @param saleId The sale id to add a product to
	 * @param productId The id of the product to add to the sale
	 * @param qty The quantity sold of the product
	 * @throws ApplicationException When some internal error occurred while saving the data.
	 */
	public void addProductToSale(int saleId, int productId, double qty) throws ApplicationException {
		try {
			persistence.saleProductTableGateway.addProductToSale(saleId, productId, qty);
		} catch (PersistenceException e) {
			throw new ApplicationException("Internal error with selling product id " + productId, e);
		}		
	}
	
}