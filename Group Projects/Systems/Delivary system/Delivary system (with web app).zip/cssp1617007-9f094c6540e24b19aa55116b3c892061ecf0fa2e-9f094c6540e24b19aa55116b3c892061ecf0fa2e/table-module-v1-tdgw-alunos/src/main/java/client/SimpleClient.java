package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import dataaccess.OrderTableGateway;
import dataaccess.Persistence;
import dataaccess.PersistenceException;
import dataaccess.TableData;
import dataaccess.TableData.Row;
import business.ApplicationException;
import business.Customer;
import business.DiscountType;
import business.Order;
import business.Sale;

/**
 * A simple application client that uses both services.
 *	
 * @author fmartins
 * @version 1.2 (11/02/2015)
 * 
 */
public class SimpleClient {
	private static int vat;
	private static String denomination;
	private static int phoneNumber;
	private static String prodCode;
	private static String qty;
	private static BufferedReader keyboard;
	private static int customerId;
	private static int saleId;
	private static String vatc;
	private static String designation;
	private static String qty_recv;
	private static boolean bool;
	private static String resp;
	private static String nOrder;

	/**
	 * A simple interaction with the application services
	 * 
	 * @param args Command line parameters
	 */
	public static void main(String[] args) {
		try (Persistence persistence = new dataaccess.Persistence("jdbc:derby:data/derby/cssdb", "SaleSys", "")) {
			// Creates the two available services
			Customer customer = new Customer (persistence);
			Sale sale = new Sale(persistence);
			Sale salef = new Sale(persistence);
			Order cenas = new Order(persistence);
			Order cenasrecv = new Order(persistence);
			try{
				BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
				System.out.println (
					  "|-------------------------|\n"
					+ "|                         |\n"
					+ "|   Welcome to SaleSys!   |\n" 
					+ "|                         |");
				String option;
				while(true){
					System.out.println (
							  "|-------------------------|\n" 
							+ "| What do you wish to do? |\n"
							+ "|-------------------------|\n" 
							+ "|1: Add Client            |\n"
							+ "|2: New Sale              |\n" 
							+ "|3: Annul Sale            |\n"
							+ "|4: Order Products        |\n" 
							+ "|5: Order Reception       |\n"
							+ "|6: Pending Orders        |\n" 
							+ "|7: Exit                  |\n"
							+ "|-------------------------|");
					System.out.print("Option: ");
					option = bufferRead.readLine();
					switch (option){
					case "1":
						System.out.println("Add client selected!\nEnter the corresponding data:");
						System.out.print("VAT: ");
						vat = Integer.parseInt(bufferRead.readLine());
						System.out.println("Denomination: ");
						denomination = bufferRead.readLine();
						System.out.println("Phone Number: ");
						phoneNumber = Integer.parseInt(bufferRead.readLine());
						//Customer customer = new Customer(persistence);
						customer.addCustomer(vat, denomination, phoneNumber, DiscountType.SALE_AMOUNT);
						System.out.println("Client added");
						break;
					case "2":
						System.out.println("New Sale selected!\nEnter the corresponding data:");
						System.out.print("VAT: ");
						vat = Integer.parseInt(bufferRead.readLine());
						saleId = sale.newSale(vat);
						System.out.println("Write the product code and the quantity (empty values to finish adding products)");
						System.out.println("Product Code: ");
						prodCode = bufferRead.readLine();
						System.out.println("Quantity: ");
						qty = bufferRead.readLine();
						while (!prodCode.equals("")) {
							sale.addProductToSale(saleId, Integer.parseInt(prodCode), Double.parseDouble(qty));
							System.out.println("Product Code: ");
							prodCode = bufferRead.readLine();
							System.out.println("Quantity: ");
							try{
								qty = bufferRead.readLine();
							} catch(NumberFormatException e){}
						}
						System.out.println("Products added");
						break;
					case "3":
						System.out.println("Annul Sale selected!\nEnter the corresponding data:");
						System.out.print("VAT: ");
						vat = Integer.parseInt(bufferRead.readLine());
						TableData customerannul = persistence.customerTableGateway.findWithVATNumber(vat);
						Row row = customerannul.iterator().next();
						customerId = persistence.customerTableGateway.readID(row);
						TableData salec = persistence.saleTableGateway.findByCID(customerId);
						Row rowsale = salec.iterator().next();
						saleId = persistence.saleTableGateway.readId(rowsale);
						salef.annulSale(saleId);
						System.out.println("Sale Annuled");
						break;
					case "4":
						System.out.println("Order Products selected!\nEnter the corresponding data:");
						System.out.print("Number of provider: ");
						vatc = bufferRead.readLine();
						TableData provider = persistence.providerTableGateway.findWithVATNumber(Integer.parseInt(vatc));
						designation = provider.iterator().next().getString("DESIGNATION");
						//designation = persistence.providerTableGateway.readDesignation(rowProv);
						System.out.println("Designation: " + designation);
						System.out.println("Product Code: ");
						prodCode = bufferRead.readLine();
						System.out.println("Quantity: ");
						qty = bufferRead.readLine();
						cenas.newOrder(Integer.parseInt(vatc), Integer.parseInt(prodCode), Double.parseDouble(qty), designation);
						System.out.println("Order Checked");
						break;
					case "5":
						System.out.println("Order Reception selected!\nEnter the corresponding data:");
						System.out.print("Number of provider: ");
						vatc = bufferRead.readLine();
						System.out.println("Orders:");
						TableData order = persistence.orderTableGateway.findByVATC(Integer.parseInt(vatc));
						Row rowa = order.iterator().next();
						OrderTableGateway cas = persistence.orderTableGateway;
						System.out.println("Product Code: " + cas.readProduct_code(rowa));
						System.out.println("Quantity: " + cas.readQty_Pend(rowa));
						System.out.println("-----------------");
						System.out.println("Orders Reception:");
						System.out.println("Product Code: ");
						prodCode = bufferRead.readLine();
						double qty_order = cas.readQty_Ord(rowa);
						do{
							System.out.println("Quantity: ");
							qty_recv = bufferRead.readLine();
							if (Double.parseDouble(qty_recv) >= qty_order){
								System.out.println("Quantity bigger than order");
							}
						}
						while (Double.parseDouble(qty_recv) >= qty_order);
						cenasrecv.recvOrder(Integer.parseInt(prodCode), Integer.parseInt(vatc), Double.parseDouble(qty_recv));
						System.out.println("Reception Order Checked");
						break;
					case "6":
						try{
							System.out.println("Pending Orders selected!\nEnter the corresponding data:");
							System.out.println("Product Code: ");
							prodCode = bufferRead.readLine();
							TableData prod = persistence.orderTableGateway.findByProdCode(Integer.parseInt(prodCode));
							Row r = prod.iterator().next();
							System.out.println("ID: "+r.getInt("ID"));
							bool = true;
							do{
								System.out.println("Do you want to see the Pending Orders?");
								resp = bufferRead.readLine();
								if (resp.equals("yes")||resp.equals("Y")||resp.equals("Yes")||resp.equals("y")||resp.equals("YES")) {
									System.out.println("Number of Order: ");
									nOrder = bufferRead.readLine();
									TableData parciala = persistence.orderTableGateway.getOrderByIdParcial(Integer.parseInt(nOrder));
									Row ro = parciala.iterator().next();
									OrderTableGateway parcial = persistence.orderTableGateway;
									if (ro !=null){
										System.out.print("Receive date: ");
										System.out.println(parcial.readDate_recv(ro));
										System.out.print("Quantity: ");
										System.out.println(parcial.readQty_Pend(ro));
									} else{
										System.out.println("This order had no partial delivery");
									}
								}
								else{
									System.out.println("Pending Orders Checked");
									bool = false;
								}
							} while(bool);
						} catch (PersistenceException e){
							throw new PersistenceException("No Pending Orders number", e);
						}
						break;
					case "7":
						System.out.print("Exiting.");
						Thread.sleep(1000);
						System.out.print(".");
						Thread.sleep(1000);
						System.out.print(".");
						Thread.sleep(1000);
						bufferRead.close();
						try {
							keyboard.close();
						} catch (NullPointerException e) {
						}
						System.exit(0);
					default:
						System.out.println("The option chosen is invalid!");
						break;
					}
					System.out.println("\n\n\n\n\n");
				}
			} catch (IOException|InterruptedException|ApplicationException|PersistenceException e) {
				e.printStackTrace();
			}
		} catch (PersistenceException e) {
			System.out.println("Error connecting database");
			System.out.println("Application Message: " + e.getMessage());
			System.out.println("SQLException: " + e.getCause().getMessage());
			return;
		}
	}
}